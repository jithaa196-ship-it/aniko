'use client'

import { useCallback, useSyncExternalStore } from 'react'

const listeners = new Map<string, Set<() => void>>()
const cache = new Map<string, { raw: string | null; value: unknown }>()

function subscribe(key: string, cb: () => void) {
  if (!listeners.has(key)) listeners.set(key, new Set())
  listeners.get(key)!.add(cb)
  const onStorage = (e: StorageEvent) => {
    if (e.key === key) cb()
  }
  window.addEventListener('storage', onStorage)
  return () => {
    listeners.get(key)?.delete(cb)
    window.removeEventListener('storage', onStorage)
  }
}

function read<T>(key: string, fallback: T): T {
  let raw: string | null = null
  try {
    raw = window.localStorage.getItem(key)
  } catch {
    return fallback
  }
  const hit = cache.get(key)
  if (hit && hit.raw === raw) return hit.value as T
  let value: T = fallback
  if (raw !== null) {
    try {
      value = JSON.parse(raw) as T
    } catch {
      value = fallback
    }
  }
  cache.set(key, { raw, value })
  return value
}

/** Persists JSON state in localStorage and syncs every component using the same key. */
export function useLocalStorage<T>(key: string, fallback: T) {
  const value = useSyncExternalStore(
    (cb) => subscribe(key, cb),
    () => read(key, fallback),
    () => fallback,
  )

  const setValue = useCallback(
    (next: T | ((prev: T) => T)) => {
      const prev = read(key, fallback)
      const resolved = typeof next === 'function' ? (next as (p: T) => T)(prev) : next
      try {
        window.localStorage.setItem(key, JSON.stringify(resolved))
      } catch {
        /* storage full or blocked — state stays in cache only */
      }
      listeners.get(key)?.forEach((l) => l())
    },
    // fallback is intentionally excluded: callers pass inline literals
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [key],
  )

  return [value, setValue] as const
}
