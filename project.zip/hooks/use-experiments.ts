'use client'

import { useCallback } from 'react'
import { toast } from 'sonner'
import { useLocalStorage } from './use-local-storage'

export type ExperimentType = 'colour' | 'gradient' | 'type' | 'ui' | 'pattern'

export interface Experiment<T = unknown> {
  id: string
  type: ExperimentType
  name: string
  data: T
  preview?: string
  createdAt: string
}

export const experimentLabels: Record<ExperimentType, string> = {
  colour: 'Colour palette',
  gradient: 'Gradient',
  type: 'Typography',
  ui: 'UI component',
  pattern: 'Pattern',
}

export function useExperiments() {
  const [items, setItems] = useLocalStorage<Experiment[]>('aniko:experiments', [])

  const save = useCallback(
    <T,>(type: ExperimentType, data: T, preview?: string, name?: string) => {
      const exp: Experiment<T> = {
        id: crypto.randomUUID(),
        type,
        data,
        preview,
        name: name || `${experimentLabels[type]} ${new Date().toLocaleString()}`,
        createdAt: new Date().toISOString(),
      }
      setItems((prev) => [exp, ...prev].slice(0, 200))
      toast.success('Experiment saved', { description: 'Find it in the Experiment Saver.' })
    },
    [setItems],
  )

  const remove = useCallback((id: string) => setItems((prev) => prev.filter((e) => e.id !== id)), [setItems])
  const rename = useCallback((id: string, name: string) => setItems((prev) => prev.map((e) => (e.id === id ? { ...e, name } : e))), [setItems])

  return { items, setItems, save, remove, rename }
}
