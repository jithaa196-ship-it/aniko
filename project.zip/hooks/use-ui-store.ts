'use client'

import useSWR from 'swr'

interface UIState {
  paletteOpen: boolean
  nikoOpen: boolean
}

const initial: UIState = { paletteOpen: false, nikoOpen: false }

/** Shared client UI state (command palette + NIKO panel) via SWR's cache. */
export function useUIStore() {
  const { data, mutate } = useSWR<UIState>('aniko:ui', null, { fallbackData: initial })
  const state = data ?? initial
  const set = (patch: Partial<UIState>) => mutate((prev) => ({ ...(prev ?? initial), ...patch }), { revalidate: false })
  return {
    ...state,
    setPaletteOpen: (v: boolean) => set({ paletteOpen: v }),
    setNikoOpen: (v: boolean) => set({ nikoOpen: v }),
  }
}
