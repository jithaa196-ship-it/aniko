import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Geist, Geist_Mono, Unbounded } from 'next/font/google'
import { AppShell } from '@/components/site/app-shell'
import { siteConfig } from '@/lib/site-config'
import './globals.css'

const geist = Geist({ subsets: ['latin'], variable: '--font-geist' })
const geistMono = Geist_Mono({ subsets: ['latin'], variable: '--font-geist-mono' })
const unbounded = Unbounded({ subsets: ['latin'], variable: '--font-unbounded', weight: ['300', '400', '500', '700'] })

export const metadata: Metadata = {
  metadataBase: new URL(siteConfig.url),
  title: {
    default: `${siteConfig.name} — ${siteConfig.tagline}`,
    template: `%s · ${siteConfig.name}`,
  },
  description: siteConfig.description,
  applicationName: siteConfig.name,
  authors: [{ name: siteConfig.creator.name }],
  creator: siteConfig.creator.name,
  keywords: ['ANIKO', 'Abhijitha JM', 'creative technology', '3D', 'UI/UX', 'AI assistant', 'portfolio'],
  openGraph: {
    title: `${siteConfig.name} — ${siteConfig.tagline}`,
    description: siteConfig.description,
    type: 'website',
    images: ['/projects/experiment.png'],
  },
  twitter: { card: 'summary_large_image', title: siteConfig.name, description: siteConfig.description },
  generator: 'v0.app',
  icons: { icon: '/icon.svg' },
}

export const viewport: Viewport = {
  colorScheme: 'dark light',
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#f5f3fa' },
    { media: '(prefers-color-scheme: dark)', color: '#100d24' },
  ],
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" suppressHydrationWarning className={`${geist.variable} ${geistMono.variable} ${unbounded.variable}`}>
      <body className="antialiased">
        <AppShell>{children}</AppShell>
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
