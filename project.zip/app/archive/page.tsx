import type { Metadata } from 'next'
import { PageIntro } from '@/components/site/page-intro'
import { Archive } from '@/components/archive/archive'

export const metadata: Metadata = {
  title: 'Knowledge Archive',
  description: 'A searchable personal archive of design inspiration, ideas, learning notes and discoveries.',
}

export default function ArchivePage() {
  return (
    <div className="mx-auto max-w-7xl px-4 pb-20 pt-28 md:px-8">
      <PageIntro index="06" eyebrow="Archive" title="Knowledge Archive" description="A living notebook of inspiration, learning notes and discoveries. Create, edit, tag and search — entries are stored in this browser." />
      <div className="mt-10"><Archive /></div>
    </div>
  )
}
