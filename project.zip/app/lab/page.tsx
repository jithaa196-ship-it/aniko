import type { Metadata } from 'next'
import { PageIntro } from '@/components/site/page-intro'
import { Lab } from '@/components/lab/lab'

export const metadata: Metadata = {
  title: '3D Laboratory',
  description: 'Rotate, zoom and restyle 3D objects with live materials, lighting and screenshots.',
}

export default function LabPage() {
  return (
    <div className="mx-auto max-w-7xl px-4 pb-20 pt-28 md:px-8">
      <PageIntro index="04" eyebrow="Experiments" title="3D Laboratory" description="A real-time WebGL bench. Swap objects, materials and lighting rigs, tune the motion, then capture a screenshot." />
      <div className="mt-10"><Lab /></div>
    </div>
  )
}
