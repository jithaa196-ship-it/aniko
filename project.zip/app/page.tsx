import { Hero } from '@/components/home/hero'
import { IntroSequence } from '@/components/home/intro-sequence'
import { UniverseSection } from '@/components/home/universe-section'
import { ZoneHighlights } from '@/components/home/zone-highlights'

export default function HomePage() {
  return (
    <>
      <IntroSequence />
      <Hero />
      <UniverseSection />
      <ZoneHighlights />
    </>
  )
}
