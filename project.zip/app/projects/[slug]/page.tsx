import type { Metadata } from 'next'
import Image from 'next/image'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { ArrowLeft, ArrowUpRight, Info } from 'lucide-react'
import { projects } from '@/lib/projects'

export function generateStaticParams() {
  return projects.map((p) => ({ slug: p.slug }))
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params
  const p = projects.find((x) => x.slug === slug)
  return p ? { title: p.title, description: p.summary } : {}
}

const sections = [
  ['overview', 'Overview'],
  ['problem', 'Problem'],
  ['research', 'Research'],
  ['ideation', 'Ideation'],
  ['process', 'Design process'],
  ['technology', 'Technology'],
  ['outcome', 'Final outcome'],
  ['learnings', 'Learnings'],
] as const

export default async function ProjectPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const idx = projects.findIndex((x) => x.slug === slug)
  if (idx === -1) notFound()
  const p = projects[idx]
  const next = projects[(idx + 1) % projects.length]

  return (
    <article className="mx-auto max-w-5xl px-4 pb-20 pt-28 md:px-8">
      <Link href="/projects" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="size-4" /> All projects
      </Link>

      {p.isPlaceholder && (
        <p className="mt-6 flex items-start gap-3 rounded-2xl border border-primary/30 bg-primary/10 p-4 text-sm">
          <Info className="mt-0.5 size-4 shrink-0 text-primary" />
          This is a placeholder case study. Replace it with real content in <code className="font-mono">lib/projects.ts</code>.
        </p>
      )}

      <header className="mt-8">
        <p className="eyebrow">{p.category}</p>
        <h1 className="mt-4 text-balance font-display text-4xl font-medium md:text-6xl">{p.title}</h1>
        <p className="mt-6 max-w-2xl text-lg text-muted-foreground">{p.summary}</p>
        <dl className="mt-8 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-border bg-border md:grid-cols-4">
          {[
            ['Status', p.status],
            ['Date', new Date(p.date).toLocaleDateString('en', { month: 'short', year: 'numeric' })],
            ['Tools', p.tools.join(', ')],
            ['Category', p.category],
          ].map(([k, v]) => (
            <div key={k} className="bg-background p-4">
              <dt className="font-mono text-xs text-muted-foreground">{k}</dt>
              <dd className="mt-1 text-sm">{v}</dd>
            </div>
          ))}
        </dl>
        {(p.githubUrl || p.liveUrl) && (
          <div className="mt-6 flex gap-3">
            {p.liveUrl && <a href={p.liveUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 rounded-full bg-primary px-4 py-2 text-sm text-primary-foreground">Live <ArrowUpRight className="size-4" /></a>}
            {p.githubUrl && <a href={p.githubUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 rounded-full border border-border px-4 py-2 text-sm">GitHub <ArrowUpRight className="size-4" /></a>}
          </div>
        )}
      </header>

      <div className="relative mt-12 aspect-[16/9] overflow-hidden rounded-3xl border border-border">
        <Image src={p.cover} alt={`${p.title} cover`} fill priority sizes="(min-width: 1024px) 1024px, 100vw" className="object-cover" />
      </div>

      <div className="mt-16 grid gap-12 md:grid-cols-[180px_1fr]">
        <nav aria-label="Case study sections" className="hidden md:block">
          <ol className="sticky top-24 flex flex-col gap-2 text-sm text-muted-foreground">
            {sections.map(([id, label], i) => (
              <li key={id}><a href={`#${id}`} className="hover:text-foreground"><span className="font-mono text-xs">{String(i + 1).padStart(2, '0')}</span> {label}</a></li>
            ))}
          </ol>
        </nav>
        <div className="flex flex-col gap-12">
          {sections.map(([id, label], i) => (
            <section key={id} id={id} className="scroll-mt-24">
              <p className="font-mono text-xs text-primary">{String(i + 1).padStart(2, '0')}</p>
              <h2 className="mt-2 font-display text-2xl">{label}</h2>
              <p className="mt-4 leading-relaxed text-muted-foreground">{p.caseStudy[id]}</p>
              {id === 'outcome' && p.gallery.length > 0 && (
                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  {p.gallery.map((g, gi) => (
                    <div key={g + gi} className="relative aspect-[4/3] overflow-hidden rounded-2xl border border-border">
                      <Image src={g} alt={`${p.title} gallery image ${gi + 1}`} fill sizes="(min-width: 640px) 50vw, 100vw" className="object-cover" />
                    </div>
                  ))}
                </div>
              )}
            </section>
          ))}
        </div>
      </div>

      <Link href={`/projects/${next.slug}`} className="group mt-20 flex items-center justify-between rounded-3xl border border-border p-6 hover:border-primary">
        <div>
          <p className="eyebrow">Next project</p>
          <p className="mt-2 font-display text-xl">{next.title}</p>
        </div>
        <ArrowUpRight className="size-6 transition-transform group-hover:rotate-45" />
      </Link>
    </article>
  )
}
