import type { Metadata } from 'next'
import { PageIntro } from '@/components/site/page-intro'
import { ProjectGallery } from '@/components/projects/project-gallery'

export const metadata: Metadata = {
  title: 'Project Exhibition',
  description: 'UI/UX, graphic design, web, electronics and creative experiments by Abhijitha JM.',
}

export default function ProjectsPage() {
  return (
    <div className="mx-auto max-w-7xl px-4 pb-20 pt-28 md:px-8">
      <PageIntro index="05" eyebrow="Exhibition" title="Project Exhibition" description="Case studies across design, code and hardware. Entries marked “Sample slot” are clearly labelled placeholders awaiting real work." />
      <div className="mt-10"><ProjectGallery /></div>
    </div>
  )
}
