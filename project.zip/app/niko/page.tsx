import type { Metadata } from 'next'
import { NikoConversation } from '@/components/niko/niko-conversation'
import { NikoAvatar } from '@/components/niko/niko-avatar'
import { PageIntro } from '@/components/site/page-intro'

export const metadata: Metadata = {
  title: 'NIKO AI',
  description: 'Chat with NIKO, the holographic AI guide of ANIKO.',
}

const abilities = [
  'Explains every zone and tool on ANIKO',
  'Answers questions about the creator — only from verified info',
  'Recommends where to go next and links you there',
  'Helps with design tools, colour and typography questions',
]

export default function NikoPage() {
  return (
    <div className="mx-auto max-w-7xl px-4 pb-16 pt-28 md:px-8">
      <PageIntro index="02" eyebrow="AI assistant" title="Meet NIKO" description="A friendly holographic lab assistant who knows ANIKO inside out." />
      <div className="mt-10 grid gap-6 lg:grid-cols-[320px_1fr]">
        <aside className="glass flex flex-col gap-6 rounded-3xl p-6">
          <div className="grid place-items-center py-6">
            <NikoAvatar state="speaking" className="size-36 text-5xl" />
          </div>
          <div>
            <p className="eyebrow mb-3">Capabilities</p>
            <ul className="flex flex-col gap-2 text-sm text-muted-foreground">
              {abilities.map((a) => (
                <li key={a} className="flex gap-2">
                  <span aria-hidden="true" className="mt-2 size-1.5 shrink-0 rounded-full bg-primary" />
                  {a}
                </li>
              ))}
            </ul>
          </div>
          <p className="rounded-xl border border-border p-3 text-xs leading-relaxed text-muted-foreground">
            If the AI service is unavailable, NIKO switches to a guided mode that answers from the site&apos;s own data.
          </p>
        </aside>
        <section aria-label="Conversation with NIKO" className="glass flex h-[70dvh] min-h-[480px] flex-col overflow-hidden rounded-3xl">
          <NikoConversation />
        </section>
      </div>
    </div>
  )
}
