import type { Metadata } from 'next'
import { Suspense } from 'react'
import Link from 'next/link'
import { Box } from 'lucide-react'
import { PageIntro } from '@/components/site/page-intro'
import { Studio } from '@/components/studio/studio'

export const metadata: Metadata = {
  title: 'Creative Studio',
  description: 'Colour, gradient, typography, UI component and pattern experiments — save and export your creations.',
}

export default function StudioPage() {
  return (
    <div className="mx-auto max-w-7xl px-4 pb-20 pt-28 md:px-8">
      <PageIntro index="03" eyebrow="Experiments" title="Creative Studio" description="Six working labs for colour, gradients, type, UI components and generative patterns. Everything you save stays in this browser.">
        <Link href="/lab" className="glass inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm hover:border-primary">
          <Box className="size-4" /> Open 3D Laboratory
        </Link>
      </PageIntro>
      <div className="mt-10">
        <Suspense fallback={<div className="h-[600px] animate-pulse rounded-3xl bg-muted" />}>
          <Studio />
        </Suspense>
      </div>
    </div>
  )
}
