import { convertToModelMessages, createUIMessageStreamResponse, streamText, toUIMessageStream, type UIMessage } from 'ai'
import { nikoSystemPrompt } from '@/lib/niko-knowledge'
import { siteConfig } from '@/lib/site-config'

export const maxDuration = 30

const MAX_MESSAGES = 30
const MAX_CHARS = 2000

export async function POST(req: Request) {
  let messages: UIMessage[]
  try {
    const body = await req.json()
    messages = body?.messages
    if (!Array.isArray(messages) || messages.length === 0) throw new Error('invalid')
  } catch {
    return Response.json({ error: 'Invalid request body' }, { status: 400 })
  }

  const trimmed = messages.slice(-MAX_MESSAGES).map((m) => ({
    ...m,
    parts: m.parts?.map((p) => (p.type === 'text' ? { ...p, text: String(p.text).slice(0, MAX_CHARS) } : p)) ?? [],
  }))

  try {
    const result = streamText({
      model: siteConfig.niko.model,
      system: nikoSystemPrompt,
      messages: await convertToModelMessages(trimmed),
    })
    return createUIMessageStreamResponse({
      stream: toUIMessageStream({ stream: result.stream }),
    })
  } catch {
    return Response.json({ error: 'AI service unavailable' }, { status: 503 })
  }
}
