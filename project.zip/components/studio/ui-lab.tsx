'use client'

import { useEffect, useState } from 'react'
import { Save } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useExperiments } from '@/hooks/use-experiments'
import { copyText } from '@/lib/export'
import { CodeBlock, ColorField, Field, LabPanel, RangeField, Segmented } from './lab-ui'
import type { Loaded } from './studio'

const KINDS = ['button', 'card', 'badge', 'input'] as const
type Kind = (typeof KINDS)[number]

interface UiData {
  kind: Kind; label: string; radius: number; padX: number; padY: number
  bg: string; fg: string; border: number; borderColor: string; shadow: number
}

const initial: UiData = { kind: 'button', label: 'Launch experiment', radius: 999, padX: 24, padY: 12, bg: '#7c5ce0', fg: '#ffffff', border: 0, borderColor: '#c4b5fd', shadow: 24 }

function styleOf(d: UiData) {
  return {
    borderRadius: Math.min(d.radius, d.kind === 'card' ? 40 : 999),
    padding: `${d.kind === 'card' ? d.padY * 2 : d.padY}px ${d.kind === 'card' ? d.padX * 1.2 : d.padX}px`,
    background: d.bg,
    color: d.fg,
    border: `${d.border}px solid ${d.borderColor}`,
    boxShadow: d.shadow ? `0 ${d.shadow / 3}px ${d.shadow}px -${d.shadow / 4}px ${d.bg}99` : 'none',
  }
}

function toCss(d: UiData) {
  const s = styleOf(d)
  return `.${d.kind} {\n  border-radius: ${s.borderRadius}px;\n  padding: ${s.padding};\n  background: ${s.background};\n  color: ${s.color};\n  border: ${s.border};\n  box-shadow: ${s.boxShadow};\n}`
}

function toHtml(d: UiData) {
  switch (d.kind) {
    case 'button': return `<button class="button">${d.label}</button>`
    case 'badge': return `<span class="badge">${d.label}</span>`
    case 'input': return `<label for="field">${d.label}</label>\n<input id="field" class="input" placeholder="${d.label}" />`
    case 'card': return `<article class="card">\n  <h3>${d.label}</h3>\n  <p>Card body copy.</p>\n</article>`
  }
}

function Preview({ d }: { d: UiData }) {
  const s = styleOf(d)
  switch (d.kind) {
    case 'button':
      return <button type="button" style={s} className="font-medium transition-transform hover:scale-[1.03] active:scale-95">{d.label}</button>
    case 'badge':
      return <span style={{ ...s, padding: `${d.padY / 2}px ${d.padX / 2}px` }} className="font-mono text-xs uppercase tracking-wider">{d.label}</span>
    case 'input':
      return (
        <label className="flex w-full max-w-sm flex-col gap-2 text-sm">
          <span>{d.label}</span>
          <input style={s} placeholder={d.label} className="outline-none" />
        </label>
      )
    case 'card':
      return (
        <article style={s} className="w-full max-w-sm">
          <p className="font-mono text-xs opacity-70">Component</p>
          <h3 className="mt-2 font-display text-2xl">{d.label}</h3>
          <p className="mt-3 text-sm opacity-80">A card generated in the ANIKO UI Component Lab.</p>
        </article>
      )
  }
}

export function UiLab({ loaded }: { loaded: Loaded }) {
  const { save } = useExperiments()
  const [d, setD] = useState<UiData>(initial)
  const set = (patch: Partial<UiData>) => setD((p) => ({ ...p, ...patch }))

  useEffect(() => {
    if (loaded?.exp.type === 'ui') setD(loaded.exp.data as UiData)
  }, [loaded])

  const code = `${toHtml(d)}\n\n<style>\n${toCss(d)}\n</style>`

  return (
    <LabPanel
      controls={
        <>
          <Segmented label="Component" value={d.kind} options={KINDS} onChange={(kind) => set({ kind })} />
          <Field label="Label">{(id) => <Input id={id} value={d.label} onChange={(e) => set({ label: e.target.value })} />}</Field>
          <RangeField label="Radius" value={Math.min(d.radius, 60)} min={0} max={60} unit="px" onChange={(radius) => set({ radius: radius === 60 ? 999 : radius })} />
          <RangeField label="Padding X" value={d.padX} min={4} max={48} unit="px" onChange={(padX) => set({ padX })} />
          <RangeField label="Padding Y" value={d.padY} min={4} max={32} unit="px" onChange={(padY) => set({ padY })} />
          <RangeField label="Border" value={d.border} min={0} max={6} unit="px" onChange={(border) => set({ border })} />
          <RangeField label="Glow" value={d.shadow} min={0} max={60} onChange={(shadow) => set({ shadow })} />
          <div className="grid grid-cols-3 gap-3">
            <ColorField label="Fill" value={d.bg} onChange={(bg) => set({ bg })} />
            <ColorField label="Text" value={d.fg} onChange={(fg) => set({ fg })} />
            <ColorField label="Border" value={d.borderColor} onChange={(borderColor) => set({ borderColor })} />
          </div>
          <Button onClick={() => save<UiData>('ui', d, d.bg)}><Save className="size-4" /> Save</Button>
        </>
      }
      preview={
        <>
          <div className="grid-bg-wrap relative grid min-h-80 place-items-center overflow-hidden rounded-3xl border border-border bg-card p-8 md:min-h-96">
            <div aria-hidden="true" className="grid-bg absolute inset-0" />
            <div className="relative flex w-full justify-center"><Preview d={d} /></div>
          </div>
          <Button variant="outline" size="sm" className="w-fit" onClick={() => copyText(code, 'Component code copied')}>Copy HTML + CSS</Button>
          <CodeBlock label={`${d.kind}.html`} code={code} />
        </>
      }
    />
  )
}
