'use client'

import { useEffect, useState } from 'react'
import { Download, Minus, Plus, Save, Shuffle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useExperiments } from '@/hooks/use-experiments'
import { copyText, downloadCanvas, randomHex } from '@/lib/export'
import { CodeBlock, ColorField, LabPanel, RangeField, Segmented } from './lab-ui'
import type { Loaded } from './studio'

const TYPES = ['linear', 'radial', 'conic'] as const
type GType = (typeof TYPES)[number]
interface Stop { color: string; pos: number }
interface GradientData { type: GType; angle: number; stops: Stop[] }

export function gradientCss({ type, angle, stops }: GradientData) {
  const s = stops.map((x) => `${x.color} ${x.pos}%`).join(', ')
  if (type === 'linear') return `linear-gradient(${angle}deg, ${s})`
  if (type === 'radial') return `radial-gradient(circle at center, ${s})`
  return `conic-gradient(from ${angle}deg, ${s})`
}

export function GradientLab({ loaded }: { loaded: Loaded }) {
  const { save } = useExperiments()
  const [type, setType] = useState<GType>('linear')
  const [angle, setAngle] = useState(135)
  const [stops, setStops] = useState<Stop[]>([
    { color: '#a78bfa', pos: 0 },
    { color: '#f472b6', pos: 55 },
    { color: '#67e8f9', pos: 100 },
  ])

  useEffect(() => {
    if (loaded?.exp.type !== 'gradient') return
    const d = loaded.exp.data as GradientData
    setType(d.type); setAngle(d.angle); setStops(d.stops)
  }, [loaded])

  const data = { type, angle, stops }
  const css = gradientCss(data)
  const update = (i: number, patch: Partial<Stop>) => setStops((s) => s.map((x, j) => (j === i ? { ...x, ...patch } : x)))

  const exportPng = () => {
    const c = document.createElement('canvas')
    c.width = 1600
    c.height = 1000
    const ctx = c.getContext('2d')!
    let g: CanvasGradient
    if (type === 'linear') {
      const r = ((angle - 90) * Math.PI) / 180
      const len = Math.abs(c.width * Math.cos(r)) / 2 + Math.abs(c.height * Math.sin(r)) / 2
      g = ctx.createLinearGradient(800 - Math.cos(r) * len, 500 - Math.sin(r) * len, 800 + Math.cos(r) * len, 500 + Math.sin(r) * len)
    } else if (type === 'radial') {
      g = ctx.createRadialGradient(800, 500, 0, 800, 500, Math.hypot(800, 500))
    } else {
      g = ctx.createConicGradient(((angle - 90) * Math.PI) / 180, 800, 500)
    }
    stops.forEach((s) => g.addColorStop(s.pos / 100, s.color))
    ctx.fillStyle = g
    ctx.fillRect(0, 0, c.width, c.height)
    downloadCanvas(c, 'aniko-gradient.png')
  }

  const randomise = () => {
    setAngle(Math.round(Math.random() * 360))
    setStops((s) => s.map((x) => ({ ...x, color: randomHex() })))
  }

  return (
    <LabPanel
      controls={
        <>
          <Segmented label="Type" value={type} options={TYPES} onChange={setType} />
          {type !== 'radial' && <RangeField label="Angle" value={angle} min={0} max={360} unit="°" onChange={setAngle} />}
          {stops.map((s, i) => (
            <div key={i} className="grid grid-cols-[1fr_1fr] items-end gap-3 rounded-2xl border border-border p-3">
              <ColorField label={`Stop ${i + 1}`} value={s.color} onChange={(color) => update(i, { color })} />
              <RangeField label="Position" value={s.pos} min={0} max={100} unit="%" onChange={(pos) => update(i, { pos })} />
            </div>
          ))}
          <div className="grid grid-cols-2 gap-2">
            <Button variant="outline" size="sm" disabled={stops.length >= 5} onClick={() => setStops((s) => [...s, { color: randomHex(), pos: 100 }])}>
              <Plus className="size-4" /> Stop
            </Button>
            <Button variant="outline" size="sm" disabled={stops.length <= 2} onClick={() => setStops((s) => s.slice(0, -1))}>
              <Minus className="size-4" /> Stop
            </Button>
            <Button variant="outline" onClick={randomise}><Shuffle className="size-4" /> Random</Button>
            <Button onClick={() => save<GradientData>('gradient', data, css)}><Save className="size-4" /> Save</Button>
          </div>
        </>
      }
      preview={
        <>
          <div role="img" aria-label={`${type} gradient preview`} className="h-80 rounded-3xl border border-border md:h-96" style={{ background: css }} />
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" size="sm" onClick={() => copyText(`background: ${css};`, 'CSS copied')}>Copy CSS</Button>
            <Button variant="outline" size="sm" onClick={exportPng}><Download className="size-4" /> Export PNG</Button>
          </div>
          <CodeBlock label="gradient.css" code={`.element {\n  background: ${css};\n}`} />
        </>
      }
    />
  )
}
