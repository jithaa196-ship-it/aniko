'use client'

import { useEffect, useMemo, useState } from 'react'
import { Copy, Lock, LockOpen, Save, Shuffle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useExperiments } from '@/hooks/use-experiments'
import { copyText, hexToHsl, hslToHex, luminance, readableOn } from '@/lib/export'
import { cn } from '@/lib/utils'
import { CodeBlock, ColorField, LabPanel, Segmented } from './lab-ui'
import type { Loaded } from './studio'

const MODES = ['analogous', 'complementary', 'triadic', 'monochrome', 'split'] as const
type Mode = (typeof MODES)[number]

function harmony(base: string, mode: Mode): string[] {
  const { h, s, l } = hexToHsl(base)
  const at = (dh: number, dl = 0, ds = 0) => hslToHex((h + dh + 360) % 360, Math.min(100, Math.max(10, s + ds)), Math.min(92, Math.max(8, l + dl)))
  switch (mode) {
    case 'analogous': return [at(-40), at(-20), base, at(20), at(40)]
    case 'complementary': return [at(0, -25), base, at(0, 25), at(180), at(180, 20)]
    case 'triadic': return [base, at(120), at(240), at(0, 30, -20), at(120, -25)]
    case 'monochrome': return [at(0, -36), at(0, -18), base, at(0, 18), at(0, 34)]
    case 'split': return [base, at(150), at(210), at(0, 28), at(0, -28)]
  }
}

export function contrast(a: string, b: string) {
  const [l1, l2] = [luminance(a), luminance(b)].sort((x, y) => y - x)
  return (l1 + 0.05) / (l2 + 0.05)
}

interface ColourData { base: string; mode: Mode; palette: string[] }

export function ColourLab({ loaded }: { loaded: Loaded }) {
  const { save } = useExperiments()
  const [base, setBase] = useState('#7c5ce0')
  const [mode, setMode] = useState<Mode>('analogous')
  const [locked, setLocked] = useState<boolean[]>([false, false, false, false, false])
  const [palette, setPalette] = useState<string[]>(() => harmony('#7c5ce0', 'analogous'))
  const [fg, setFg] = useState(0)
  const [bg, setBg] = useState(4)

  useEffect(() => {
    if (loaded?.exp.type !== 'colour') return
    const d = loaded.exp.data as ColourData
    setBase(d.base); setMode(d.mode); setPalette(d.palette)
  }, [loaded])

  const regenerate = (b = base, m = mode) => {
    const next = harmony(b, m)
    setPalette((prev) => next.map((c, i) => (locked[i] ? prev[i] : c)))
  }

  const randomise = () => {
    const b = hslToHex(Math.random() * 360, 50 + Math.random() * 40, 40 + Math.random() * 25)
    setBase(b)
    regenerate(b)
  }

  const ratio = contrast(palette[fg], palette[bg])
  const grade = ratio >= 7 ? 'AAA' : ratio >= 4.5 ? 'AA' : ratio >= 3 ? 'AA Large' : 'Fail'

  const css = useMemo(() => `:root {\n${palette.map((c, i) => `  --palette-${i + 1}: ${c};`).join('\n')}\n}`, [palette])

  return (
    <LabPanel
      controls={
        <>
          <ColorField label="Base colour" value={base} onChange={(v) => { setBase(v); regenerate(v) }} />
          <Segmented label="Harmony" value={mode} options={MODES} onChange={(m) => { setMode(m); regenerate(base, m) }} />
          <div className="grid grid-cols-2 gap-2">
            <Button variant="outline" onClick={randomise}><Shuffle className="size-4" /> Random</Button>
            <Button onClick={() => save<ColourData>('colour', { base, mode, palette }, `linear-gradient(90deg, ${palette.join(',')})`)}>
              <Save className="size-4" /> Save
            </Button>
          </div>
          <div className="flex flex-col gap-3 rounded-2xl border border-border p-4">
            <p className="text-xs text-muted-foreground">Contrast checker — pick two swatches</p>
            <div className="flex items-center gap-2 text-xs">
              <label className="flex flex-1 flex-col gap-1">Text
                <select value={fg} onChange={(e) => setFg(+e.target.value)} className="rounded-md border border-border bg-background px-2 py-1.5">
                  {palette.map((c, i) => <option key={i} value={i}>{i + 1} · {c}</option>)}
                </select>
              </label>
              <label className="flex flex-1 flex-col gap-1">Background
                <select value={bg} onChange={(e) => setBg(+e.target.value)} className="rounded-md border border-border bg-background px-2 py-1.5">
                  {palette.map((c, i) => <option key={i} value={i}>{i + 1} · {c}</option>)}
                </select>
              </label>
            </div>
            <div className="rounded-xl p-4" style={{ background: palette[bg], color: palette[fg] }}>
              <p className="font-display text-lg">Aa — Sample text</p>
              <p className="text-xs">Body copy at 12px</p>
            </div>
            <p className="flex items-center justify-between font-mono text-xs">
              <span>{ratio.toFixed(2)} : 1</span>
              <span className={cn('rounded-full px-2 py-0.5', grade === 'Fail' ? 'bg-destructive/15 text-destructive' : 'bg-primary/15 text-primary')}>{grade}</span>
            </p>
          </div>
        </>
      }
      preview={
        <>
          <ul className="grid h-80 grid-cols-5 overflow-hidden rounded-3xl border border-border md:h-96">
            {palette.map((c, i) => (
              <li key={i} className="group relative flex flex-col justify-end gap-2 p-3" style={{ background: c, color: readableOn(c) }}>
                <button
                  type="button"
                  aria-label={locked[i] ? `Unlock colour ${i + 1}` : `Lock colour ${i + 1}`}
                  aria-pressed={locked[i]}
                  onClick={() => setLocked((l) => l.map((v, j) => (j === i ? !v : v)))}
                  className="absolute right-2 top-2 rounded-full p-1.5 opacity-70 hover:opacity-100"
                >
                  {locked[i] ? <Lock className="size-4" /> : <LockOpen className="size-4" />}
                </button>
                <button type="button" onClick={() => copyText(c, `Copied ${c}`)} className="flex items-center gap-1 text-left font-mono text-xs uppercase md:text-sm">
                  {c} <Copy className="size-3 opacity-0 transition-opacity group-hover:opacity-100" />
                </button>
              </li>
            ))}
          </ul>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" size="sm" onClick={() => copyText(css, 'CSS variables copied')}>Copy CSS variables</Button>
            <Button variant="outline" size="sm" onClick={() => copyText(JSON.stringify(palette), 'JSON copied')}>Copy JSON</Button>
          </div>
          <CodeBlock label="palette.css" code={css} />
        </>
      }
    />
  )
}
