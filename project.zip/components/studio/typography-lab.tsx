'use client'

import { useEffect, useState } from 'react'
import { Save } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { useExperiments } from '@/hooks/use-experiments'
import { copyText } from '@/lib/export'
import { CodeBlock, ColorField, Field, LabPanel, RangeField, Segmented } from './lab-ui'
import type { Loaded } from './studio'

const FONTS = {
  Display: 'var(--font-display)',
  Sans: 'var(--font-sans)',
  Mono: 'var(--font-mono)',
  Serif: 'Georgia, "Times New Roman", serif',
} as const
type FontKey = keyof typeof FONTS
const TRANSFORMS = ['none', 'uppercase', 'lowercase', 'capitalize'] as const

interface TypeData {
  text: string; font: FontKey; size: number; weight: number; tracking: number; leading: number
  transform: (typeof TRANSFORMS)[number]; color: string; bg: string
}

const initial: TypeData = { text: 'Explore. Experiment. Evolve.', font: 'Display', size: 72, weight: 500, tracking: -2, leading: 1.05, transform: 'none', color: '#f5f3fa', bg: '#100d24' }

export function TypographyLab({ loaded }: { loaded: Loaded }) {
  const { save } = useExperiments()
  const [d, setD] = useState<TypeData>(initial)
  const set = (patch: Partial<TypeData>) => setD((p) => ({ ...p, ...patch }))

  useEffect(() => {
    if (loaded?.exp.type === 'type') setD(loaded.exp.data as TypeData)
  }, [loaded])

  const style = {
    fontFamily: FONTS[d.font],
    fontSize: `${d.size}px`,
    fontWeight: d.weight,
    letterSpacing: `${d.tracking / 100}em`,
    lineHeight: d.leading,
    textTransform: d.transform,
    color: d.color,
  } as const

  const css = `.headline {\n  font-family: ${FONTS[d.font]};\n  font-size: ${d.size}px;\n  font-weight: ${d.weight};\n  letter-spacing: ${d.tracking / 100}em;\n  line-height: ${d.leading};\n  text-transform: ${d.transform};\n  color: ${d.color};\n}`

  return (
    <LabPanel
      controls={
        <>
          <Field label="Sample text">{(id) => <Textarea id={id} value={d.text} onChange={(e) => set({ text: e.target.value })} rows={2} />}</Field>
          <Segmented label="Typeface" value={d.font} options={Object.keys(FONTS) as FontKey[]} onChange={(font) => set({ font })} />
          <RangeField label="Size" value={d.size} min={12} max={160} unit="px" onChange={(size) => set({ size })} />
          <RangeField label="Weight" value={d.weight} min={100} max={900} step={100} onChange={(weight) => set({ weight })} />
          <RangeField label="Letter spacing" value={d.tracking} min={-10} max={40} unit="/100em" onChange={(tracking) => set({ tracking })} />
          <RangeField label="Line height" value={d.leading} min={0.8} max={2.2} step={0.05} onChange={(leading) => set({ leading })} />
          <Segmented label="Transform" value={d.transform} options={TRANSFORMS} onChange={(transform) => set({ transform })} />
          <div className="grid grid-cols-2 gap-3">
            <ColorField label="Text" value={d.color} onChange={(color) => set({ color })} />
            <ColorField label="Background" value={d.bg} onChange={(bg) => set({ bg })} />
          </div>
          <Button onClick={() => save<TypeData>('type', d)}><Save className="size-4" /> Save</Button>
        </>
      }
      preview={
        <>
          <div className="flex min-h-80 items-center overflow-hidden rounded-3xl border border-border p-8 md:min-h-96 md:p-12" style={{ background: d.bg }}>
            <p className="w-full break-words" style={style}>{d.text || 'Type something'}</p>
          </div>
          <div className="grid gap-px overflow-hidden rounded-2xl border border-border bg-border sm:grid-cols-3">
            {[32, 20, 14].map((s) => (
              <p key={s} className="truncate bg-background p-4" style={{ ...style, fontSize: s, color: undefined }}>{d.text}</p>
            ))}
          </div>
          <Button variant="outline" size="sm" className="w-fit" onClick={() => copyText(css, 'CSS copied')}>Copy CSS</Button>
          <CodeBlock label="typography.css" code={css} />
        </>
      }
    />
  )
}
