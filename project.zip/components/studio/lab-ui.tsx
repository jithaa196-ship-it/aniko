'use client'

import { useId } from 'react'
import { Label } from '@/components/ui/label'
import { Slider } from '@/components/ui/slider'
import { cn } from '@/lib/utils'

export function LabPanel({ controls, preview, className }: { controls: React.ReactNode; preview: React.ReactNode; className?: string }) {
  return (
    <div className={cn('grid gap-6 lg:grid-cols-[340px_1fr]', className)}>
      <div className="glass flex flex-col gap-5 rounded-3xl p-5">{controls}</div>
      <div className="flex min-w-0 flex-col gap-4">{preview}</div>
    </div>
  )
}

export function Field({ label, children, hint }: { label: string; children: (id: string) => React.ReactNode; hint?: string }) {
  const id = useId()
  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <Label htmlFor={id} className="text-xs text-muted-foreground">{label}</Label>
        {hint && <span className="font-mono text-xs text-muted-foreground">{hint}</span>}
      </div>
      {children(id)}
    </div>
  )
}

export function RangeField({ label, value, min, max, step = 1, onChange, unit = '' }: {
  label: string; value: number; min: number; max: number; step?: number; unit?: string; onChange: (v: number) => void
}) {
  return (
    <Field label={label} hint={`${value}${unit}`}>
      {(id) => <Slider id={id} aria-label={label} value={[value]} min={min} max={max} step={step} onValueChange={([v]) => onChange(v)} />}
    </Field>
  )
}

export function ColorField({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <Field label={label} hint={value.toUpperCase()}>
      {(id) => (
        <input
          id={id}
          type="color"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="h-10 w-full cursor-pointer rounded-lg border border-border bg-transparent p-1"
        />
      )}
    </Field>
  )
}

export function CodeBlock({ code, label }: { code: string; label: string }) {
  return (
    <figure className="overflow-hidden rounded-2xl border border-border bg-card">
      <figcaption className="border-b border-border px-4 py-2 font-mono text-xs text-muted-foreground">{label}</figcaption>
      <pre className="max-h-64 overflow-auto p-4 font-mono text-xs leading-relaxed"><code>{code}</code></pre>
    </figure>
  )
}

export function Segmented<T extends string>({ label, value, options, onChange }: {
  label: string; value: T; options: readonly T[]; onChange: (v: T) => void
}) {
  return (
    <div role="radiogroup" aria-label={label} className="flex flex-col gap-2">
      <span className="text-xs text-muted-foreground">{label}</span>
      <div className="flex flex-wrap gap-1 rounded-xl bg-muted p-1">
        {options.map((o) => (
          <button
            key={o}
            type="button"
            role="radio"
            aria-checked={value === o}
            onClick={() => onChange(o)}
            className={cn(
              'flex-1 rounded-lg px-2.5 py-1.5 text-xs capitalize transition-colors',
              value === o ? 'bg-background text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground',
            )}
          >
            {o}
          </button>
        ))}
      </div>
    </div>
  )
}
