'use client'

import { useEffect, useRef, useState } from 'react'
import { Download, Save, Shuffle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useExperiments } from '@/hooks/use-experiments'
import { downloadCanvas, randomHex } from '@/lib/export'
import { ColorField, LabPanel, RangeField, Segmented } from './lab-ui'
import type { Loaded } from './studio'

const STYLES = ['dots', 'waves', 'truchet', 'triangles', 'rings'] as const
type PStyle = (typeof STYLES)[number]
interface PatternData { style: PStyle; seed: number; density: number; stroke: number; bg: string; a: string; b: string }

function rng(seed: number) {
  let s = seed >>> 0
  return () => {
    s = (s + 0x6d2b79f5) >>> 0
    let t = s
    t = Math.imul(t ^ (t >>> 15), t | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

export function drawPattern(ctx: CanvasRenderingContext2D, w: number, h: number, d: PatternData) {
  const r = rng(d.seed)
  ctx.fillStyle = d.bg
  ctx.fillRect(0, 0, w, h)
  ctx.lineWidth = d.stroke
  ctx.lineCap = 'round'
  const cell = Math.max(10, Math.round(w / d.density))
  const pick = () => (r() > 0.5 ? d.a : d.b)

  for (let y = 0; y < h + cell; y += cell) {
    for (let x = 0; x < w + cell; x += cell) {
      ctx.strokeStyle = pick()
      ctx.fillStyle = pick()
      switch (d.style) {
        case 'dots': {
          ctx.beginPath()
          ctx.arc(x + cell / 2, y + cell / 2, (cell / 2.4) * (0.3 + r() * 0.7), 0, Math.PI * 2)
          ctx.fill()
          break
        }
        case 'truchet': {
          ctx.beginPath()
          if (r() > 0.5) {
            ctx.arc(x, y, cell / 2, 0, Math.PI / 2)
            ctx.moveTo(x + cell, y + cell / 2)
            ctx.arc(x + cell, y + cell, cell / 2, -Math.PI / 2, -Math.PI, true)
          } else {
            ctx.arc(x + cell, y, cell / 2, Math.PI / 2, Math.PI)
            ctx.moveTo(x + cell / 2, y + cell)
            ctx.arc(x, y + cell, cell / 2, -Math.PI / 2, 0)
          }
          ctx.stroke()
          break
        }
        case 'triangles': {
          ctx.beginPath()
          const flip = r() > 0.5
          ctx.moveTo(x, y)
          ctx.lineTo(x + cell, flip ? y : y + cell)
          ctx.lineTo(flip ? x : x + cell, y + cell)
          ctx.closePath()
          if (r() > 0.4) ctx.fill()
          else ctx.stroke()
          break
        }
        case 'rings': {
          ctx.beginPath()
          ctx.arc(x + cell / 2, y + cell / 2, cell / 2.5, r() * Math.PI * 2, r() * Math.PI * 2 + Math.PI * (0.5 + r()))
          ctx.stroke()
          break
        }
        case 'waves':
          break
      }
    }
  }

  if (d.style === 'waves') {
    const rows = Math.round(d.density * 0.8)
    for (let i = 0; i < rows; i++) {
      const y0 = (h / rows) * i + h / rows / 2
      const amp = (h / rows) * (0.3 + r())
      const freq = 0.005 + r() * 0.02
      const phase = r() * Math.PI * 2
      ctx.strokeStyle = pick()
      ctx.beginPath()
      for (let x = 0; x <= w; x += 4) ctx.lineTo(x, y0 + Math.sin(x * freq + phase) * amp)
      ctx.stroke()
    }
  }
}

const initial: PatternData = { style: 'truchet', seed: 42, density: 14, stroke: 4, bg: '#100d24', a: '#a78bfa', b: '#67e8f9' }

export function PatternLab({ loaded }: { loaded: Loaded }) {
  const { save } = useExperiments()
  const canvas = useRef<HTMLCanvasElement>(null)
  const [d, setD] = useState<PatternData>(initial)
  const set = (patch: Partial<PatternData>) => setD((p) => ({ ...p, ...patch }))

  useEffect(() => {
    if (loaded?.exp.type === 'pattern') setD(loaded.exp.data as PatternData)
  }, [loaded])

  useEffect(() => {
    const c = canvas.current
    if (!c) return
    const ctx = c.getContext('2d')
    if (ctx) drawPattern(ctx, c.width, c.height, d)
  }, [d])

  const thumb = () => {
    const c = document.createElement('canvas')
    c.width = 240
    c.height = 160
    drawPattern(c.getContext('2d')!, 240, 160, { ...d, stroke: Math.max(1, d.stroke / 3) })
    return `url(${c.toDataURL('image/png')})`
  }

  return (
    <LabPanel
      controls={
        <>
          <Segmented label="Generator" value={d.style} options={STYLES} onChange={(style) => set({ style })} />
          <RangeField label="Seed" value={d.seed} min={1} max={999} onChange={(seed) => set({ seed })} />
          <RangeField label="Density" value={d.density} min={4} max={40} onChange={(density) => set({ density })} />
          <RangeField label="Stroke" value={d.stroke} min={1} max={16} unit="px" onChange={(stroke) => set({ stroke })} />
          <div className="grid grid-cols-3 gap-3">
            <ColorField label="Ground" value={d.bg} onChange={(bg) => set({ bg })} />
            <ColorField label="Ink A" value={d.a} onChange={(a) => set({ a })} />
            <ColorField label="Ink B" value={d.b} onChange={(b) => set({ b })} />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <Button variant="outline" onClick={() => set({ seed: Math.ceil(Math.random() * 999), a: randomHex(), b: randomHex() })}>
              <Shuffle className="size-4" /> Random
            </Button>
            <Button onClick={() => save<PatternData>('pattern', d, thumb())}><Save className="size-4" /> Save</Button>
          </div>
        </>
      }
      preview={
        <>
          <canvas ref={canvas} width={1600} height={1000} role="img" aria-label={`Generated ${d.style} pattern`} className="aspect-[16/10] w-full rounded-3xl border border-border" />
          <Button variant="outline" size="sm" className="w-fit" onClick={() => canvas.current && downloadCanvas(canvas.current, `aniko-${d.style}-${d.seed}.png`)}>
            <Download className="size-4" /> Export PNG (1600×1000)
          </Button>
        </>
      }
    />
  )
}
