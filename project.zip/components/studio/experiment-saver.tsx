'use client'

import { useRef, useState } from 'react'
import { Download, FolderOpen, Trash2, Upload } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { experimentLabels, useExperiments, type Experiment, type ExperimentType } from '@/hooks/use-experiments'
import { downloadDataUrl } from '@/lib/export'
import { cn } from '@/lib/utils'

const FILTERS = ['all', ...Object.keys(experimentLabels)] as ('all' | ExperimentType)[]

export function ExperimentSaver({ onLoad }: { onLoad: (e: Experiment) => void }) {
  const { items, setItems, remove, rename } = useExperiments()
  const [filter, setFilter] = useState<'all' | ExperimentType>('all')
  const file = useRef<HTMLInputElement>(null)
  const list = filter === 'all' ? items : items.filter((i) => i.type === filter)

  const exportAll = () => {
    const blob = new Blob([JSON.stringify(items, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    downloadDataUrl(url, 'aniko-experiments.json')
    URL.revokeObjectURL(url)
  }

  const importFile = async (f: File) => {
    try {
      const parsed = JSON.parse(await f.text())
      if (!Array.isArray(parsed)) throw new Error()
      const valid = parsed.filter((e): e is Experiment => e && typeof e.id === 'string' && e.type in experimentLabels && 'data' in e)
      setItems((prev) => [...valid.filter((v) => !prev.some((p) => p.id === v.id)), ...prev])
      toast.success(`Imported ${valid.length} experiment${valid.length === 1 ? '' : 's'}`)
    } catch {
      toast.error('That file is not a valid ANIKO export')
    }
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div role="radiogroup" aria-label="Filter experiments" className="flex flex-wrap gap-1">
          {FILTERS.map((f) => (
            <button
              key={f}
              type="button"
              role="radio"
              aria-checked={filter === f}
              onClick={() => setFilter(f)}
              className={cn('rounded-full border px-3 py-1.5 text-xs transition-colors', filter === f ? 'border-primary bg-primary text-primary-foreground' : 'border-border hover:border-primary/50')}
            >
              {f === 'all' ? `All (${items.length})` : experimentLabels[f]}
            </button>
          ))}
        </div>
        <div className="flex gap-2">
          <input ref={file} type="file" accept="application/json" className="sr-only" tabIndex={-1} aria-hidden="true" onChange={(e) => e.target.files?.[0] && importFile(e.target.files[0])} />
          <Button variant="outline" size="sm" onClick={() => file.current?.click()}><Upload className="size-4" /> Import</Button>
          <Button variant="outline" size="sm" onClick={exportAll} disabled={!items.length}><Download className="size-4" /> Export all</Button>
        </div>
      </div>

      {list.length === 0 ? (
        <div className="grid min-h-72 place-items-center rounded-3xl border border-dashed border-border p-10 text-center">
          <div className="max-w-sm">
            <FolderOpen className="mx-auto size-8 text-muted-foreground" />
            <p className="mt-4 font-display text-lg">No experiments yet</p>
            <p className="mt-2 text-sm text-muted-foreground">Press Save in any lab. Experiments are stored only in this browser — export them to keep a backup.</p>
          </div>
        </div>
      ) : (
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((e) => (
            <li key={e.id} className="glass flex flex-col overflow-hidden rounded-2xl">
              <div aria-hidden="true" className="h-32 bg-muted bg-cover bg-center" style={{ background: e.preview }} />
              <div className="flex flex-1 flex-col gap-3 p-4">
                <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{experimentLabels[e.type]} · {new Date(e.createdAt).toLocaleDateString()}</p>
                <Input aria-label="Experiment name" defaultValue={e.name} onBlur={(ev) => ev.target.value.trim() && rename(e.id, ev.target.value.trim())} className="h-8 text-sm" />
                <div className="mt-auto flex gap-2">
                  <Button size="sm" className="flex-1" onClick={() => onLoad(e)}>Open in lab</Button>
                  <Button size="sm" variant="outline" aria-label={`Delete ${e.name}`} onClick={() => remove(e.id)}><Trash2 className="size-4" /></Button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
