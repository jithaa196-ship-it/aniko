'use client'

import { usePathname, useRouter, useSearchParams } from 'next/navigation'
import { useState } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import type { Experiment } from '@/hooks/use-experiments'
import { ColourLab } from './colour-lab'
import { GradientLab } from './gradient-lab'
import { TypographyLab } from './typography-lab'
import { UiLab } from './ui-lab'
import { PatternLab } from './pattern-lab'
import { ExperimentSaver } from './experiment-saver'

const TABS = [
  { id: 'colour', label: 'Colour' },
  { id: 'gradient', label: 'Gradient' },
  { id: 'type', label: 'Typography' },
  { id: 'ui', label: 'UI Components' },
  { id: 'pattern', label: 'Pattern' },
  { id: 'saved', label: 'Saved' },
] as const

export type Loaded = { exp: Experiment; nonce: number } | null

export function Studio() {
  const params = useSearchParams()
  const router = useRouter()
  const pathname = usePathname()
  const current = TABS.some((t) => t.id === params.get('tool')) ? params.get('tool')! : 'colour'
  const [loaded, setLoaded] = useState<Loaded>(null)

  const setTab = (id: string) => router.replace(`${pathname}?tool=${id}`, { scroll: false })

  const load = (exp: Experiment) => {
    setLoaded({ exp, nonce: Date.now() })
    setTab(exp.type)
  }

  return (
    <Tabs value={current} onValueChange={setTab} className="gap-6">
      <TabsList className="h-auto w-full flex-wrap justify-start gap-1 rounded-2xl p-1 md:w-fit">
        {TABS.map((t, i) => (
          <TabsTrigger key={t.id} value={t.id} className="gap-2 rounded-xl px-4 py-2">
            <span className="font-mono text-[10px] opacity-60">{String.fromCharCode(65 + i)}</span>
            {t.label}
          </TabsTrigger>
        ))}
      </TabsList>
      <TabsContent value="colour"><ColourLab loaded={loaded} /></TabsContent>
      <TabsContent value="gradient"><GradientLab loaded={loaded} /></TabsContent>
      <TabsContent value="type"><TypographyLab loaded={loaded} /></TabsContent>
      <TabsContent value="ui"><UiLab loaded={loaded} /></TabsContent>
      <TabsContent value="pattern"><PatternLab loaded={loaded} /></TabsContent>
      <TabsContent value="saved"><ExperimentSaver onLoad={load} /></TabsContent>
    </Tabs>
  )
}
