'use client'

import { Canvas, useFrame } from '@react-three/fiber'
import { Html, OrbitControls, Stars } from '@react-three/drei'
import { useRouter } from 'next/navigation'
import { useRef, useState } from 'react'
import type { Group, Mesh } from 'three'
import { usePrefs } from '@/components/providers/prefs-provider'
import { zones, type Zone } from '@/lib/zones'

function ZoneGeometry({ shape }: { shape: Zone['shape'] }) {
  switch (shape) {
    case 'icosahedron': return <icosahedronGeometry args={[0.5, 0]} />
    case 'sphere': return <sphereGeometry args={[0.45, 32, 32]} />
    case 'torusKnot': return <torusKnotGeometry args={[0.3, 0.1, 96, 16]} />
    case 'box': return <boxGeometry args={[0.65, 0.65, 0.65]} />
    case 'octahedron': return <octahedronGeometry args={[0.5, 0]} />
    case 'cylinder': return <cylinderGeometry args={[0.3, 0.3, 0.7, 32]} />
    case 'tetrahedron': return <tetrahedronGeometry args={[0.55, 0]} />
    case 'torus': return <torusGeometry args={[0.35, 0.13, 24, 64]} />
  }
}

function ZoneNode({ zone, angle, radius, animate, onHover, active }: {
  zone: Zone; angle: number; radius: number; animate: boolean; active: boolean; onHover: (id: string | null) => void
}) {
  const ref = useRef<Mesh>(null)
  const router = useRouter()
  const { play } = usePrefs()
  useFrame((_, dt) => {
    if (!ref.current || !animate) return
    ref.current.rotation.x += dt * 0.4
    ref.current.rotation.y += dt * 0.6
  })
  const x = Math.cos(angle) * radius
  const z = Math.sin(angle) * radius
  const y = Math.sin(angle * 2) * 0.6
  return (
    <group position={[x, y, z]}>
      <mesh
        ref={ref}
        scale={active ? 1.3 : 1}
        onPointerOver={(e) => {
          e.stopPropagation()
          onHover(zone.id)
          play('hover')
          document.body.style.cursor = 'pointer'
        }}
        onPointerOut={() => {
          onHover(null)
          document.body.style.cursor = ''
        }}
        onClick={(e) => {
          e.stopPropagation()
          play('open')
          router.push(zone.href)
        }}
      >
        <ZoneGeometry shape={zone.shape} />
        <meshStandardMaterial color={zone.color} emissive={zone.color} emissiveIntensity={active ? 0.9 : 0.35} roughness={0.25} metalness={0.4} />
      </mesh>
      <Html center distanceFactor={9} position={[0, -0.9, 0]} style={{ pointerEvents: 'none' }}>
        <div
          className={`whitespace-nowrap rounded-full border px-3 py-1 font-mono text-[11px] backdrop-blur-md transition-all ${
            active ? 'border-white/40 bg-black/60 text-white' : 'border-white/10 bg-black/30 text-white/70'
          }`}
        >
          {zone.index} {zone.title}
        </div>
      </Html>
    </group>
  )
}

function Orbit({ animate, hovered, setHovered }: { animate: boolean; hovered: string | null; setHovered: (id: string | null) => void }) {
  const group = useRef<Group>(null)
  const core = useRef<Mesh>(null)
  useFrame((_, dt) => {
    if (!animate) return
    if (group.current && !hovered) group.current.rotation.y += dt * 0.08
    if (core.current) {
      core.current.rotation.y -= dt * 0.25
      core.current.rotation.x += dt * 0.1
    }
  })
  return (
    <>
      <mesh ref={core}>
        <icosahedronGeometry args={[1.1, 1]} />
        <meshStandardMaterial color="#a78bfa" wireframe emissive="#7c5ce0" emissiveIntensity={0.6} />
      </mesh>
      <mesh>
        <sphereGeometry args={[0.55, 32, 32]} />
        <meshStandardMaterial color="#f472b6" emissive="#f472b6" emissiveIntensity={0.8} />
      </mesh>
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[4, 0.008, 8, 128]} />
        <meshBasicMaterial color="#c4b5fd" transparent opacity={0.35} />
      </mesh>
      <group ref={group}>
        {zones.map((z, i) => (
          <ZoneNode
            key={z.id}
            zone={z}
            angle={(i / zones.length) * Math.PI * 2}
            radius={4}
            animate={animate}
            active={hovered === z.id}
            onHover={setHovered}
          />
        ))}
      </group>
    </>
  )
}

export default function UniverseScene({ hovered, setHovered }: { hovered: string | null; setHovered: (id: string | null) => void }) {
  const { reducedMotion } = usePrefs()
  const [ready, setReady] = useState(false)
  return (
    <div className={`size-full transition-opacity duration-1000 ${ready ? 'opacity-100' : 'opacity-0'}`}>
      <Canvas
        camera={{ position: [0, 3.2, 9], fov: 50 }}
        dpr={[1, 1.75]}
        onCreated={() => setReady(true)}
        aria-label="Interactive 3D map of ANIKO zones"
      >
        <color attach="background" args={['#0b0918']} />
        <fog attach="fog" args={['#0b0918', 10, 22]} />
        <ambientLight intensity={0.4} />
        <pointLight position={[0, 0, 0]} intensity={30} color="#f472b6" />
        <pointLight position={[6, 6, 6]} intensity={60} color="#67e8f9" />
        <Stars radius={60} depth={40} count={reducedMotion ? 800 : 2500} factor={3} fade speed={reducedMotion ? 0 : 0.6} />
        <Orbit animate={!reducedMotion} hovered={hovered} setHovered={setHovered} />
        <OrbitControls enablePan={false} enableZoom={false} autoRotate={false} minPolarAngle={Math.PI / 4} maxPolarAngle={Math.PI / 1.8} />
      </Canvas>
    </div>
  )
}
