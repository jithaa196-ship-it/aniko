import Image from 'next/image'
import Link from 'next/link'
import { ArrowUpRight } from 'lucide-react'
import { projects } from '@/lib/projects'
import { zones } from '@/lib/zones'
import { siteConfig } from '@/lib/site-config'

const marquee = ['UI/UX', 'Graphic design', 'Creative technology', 'ESP32', 'Figma', 'Generative visuals', '3D', 'AI', 'IoT', 'Typography']

export function ZoneHighlights() {
  const featured = projects.slice(0, 3)
  return (
    <>
      <div aria-hidden="true" className="overflow-hidden border-y border-border py-5">
        <div className="animate-marquee flex w-max gap-10 font-display text-2xl text-muted-foreground/60 md:text-4xl">
          {[...marquee, ...marquee].map((m, i) => (
            <span key={i} className="flex items-center gap-10">
              {m} <span className="text-primary">✦</span>
            </span>
          ))}
        </div>
      </div>

      <section aria-labelledby="zones-title" className="mx-auto max-w-7xl px-4 py-20 md:px-8 md:py-28">
        <p className="eyebrow mb-4">02 — Zones</p>
        <h2 id="zones-title" className="max-w-2xl text-balance font-display text-3xl font-medium md:text-5xl">
          Every zone is a working tool, not a screenshot.
        </h2>
        <ul className="mt-12 grid gap-px overflow-hidden rounded-3xl border border-border bg-border sm:grid-cols-2 lg:grid-cols-4">
          {zones.slice(1).map((z) => (
            <li key={z.id} className="bg-background">
              <Link href={z.href} className="group flex h-full min-h-52 flex-col justify-between gap-8 p-6 transition-colors hover:bg-card">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs text-muted-foreground">{z.index}</span>
                  <span aria-hidden="true" className="size-3 rounded-full transition-transform group-hover:scale-150" style={{ background: z.color, boxShadow: `0 0 18px ${z.color}` }} />
                </div>
                <div>
                  <h3 className="flex items-center gap-2 font-display text-lg">
                    {z.title}
                    <ArrowUpRight className="size-4 -translate-x-1 opacity-0 transition-all group-hover:translate-x-0 group-hover:opacity-100" />
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{z.description}</p>
                </div>
              </Link>
            </li>
          ))}
          <li className="bg-background">
            <Link href="/contact" className="flex h-full min-h-52 flex-col justify-between bg-primary p-6 text-primary-foreground">
              <span className="font-mono text-xs opacity-70">09</span>
              <div>
                <h3 className="font-display text-lg">Open a channel</h3>
                <p className="mt-2 text-sm opacity-80">Send a transmission to the creator.</p>
              </div>
            </Link>
          </li>
        </ul>
      </section>

      <section aria-labelledby="featured-title" className="mx-auto max-w-7xl px-4 pb-20 md:px-8 md:pb-28">
        <div className="flex items-end justify-between gap-4">
          <div>
            <p className="eyebrow mb-4">03 — Exhibition</p>
            <h2 id="featured-title" className="font-display text-3xl font-medium md:text-5xl">From the exhibition</h2>
          </div>
          <Link href="/projects" className="hidden text-sm text-muted-foreground underline-offset-4 hover:text-foreground hover:underline sm:block">
            View all projects
          </Link>
        </div>
        <ul className="mt-10 grid gap-6 md:grid-cols-3">
          {featured.map((p) => (
            <li key={p.slug}>
              <Link href={`/projects/${p.slug}`} className="group block">
                <div className="relative aspect-[4/3] overflow-hidden rounded-2xl border border-border">
                  <Image src={p.cover} alt="" fill sizes="(min-width: 768px) 33vw, 100vw" className="object-cover transition-transform duration-700 group-hover:scale-105" />
                  {p.isPlaceholder && (
                    <span className="absolute left-3 top-3 rounded-full bg-background/80 px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider backdrop-blur">
                      Sample slot
                    </span>
                  )}
                </div>
                <p className="mt-4 font-mono text-xs text-muted-foreground">{p.category}</p>
                <h3 className="mt-1 font-display text-lg">{p.title}</h3>
              </Link>
            </li>
          ))}
        </ul>
      </section>

      <section aria-labelledby="creator-title" className="border-t border-border">
        <div className="mx-auto grid max-w-7xl gap-10 px-4 py-20 md:grid-cols-2 md:px-8 md:py-28">
          <div>
            <p className="eyebrow mb-4">04 — Creator</p>
            <h2 id="creator-title" className="font-display text-3xl font-medium md:text-5xl">{siteConfig.creator.name}</h2>
          </div>
          <div className="flex flex-col gap-6">
            <p className="text-pretty text-lg leading-relaxed text-muted-foreground">{siteConfig.creator.intro}</p>
            <Link href="/creator" className="inline-flex w-fit items-center gap-2 border-b border-foreground pb-1 text-sm">
              Visit the Creator Hub <ArrowUpRight className="size-4" />
            </Link>
          </div>
        </div>
      </section>
    </>
  )
}
