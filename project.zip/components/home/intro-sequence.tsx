'use client'

import { AnimatePresence, motion } from 'motion/react'
import { useEffect, useState } from 'react'
import { usePrefs } from '@/components/providers/prefs-provider'
import { LogoMark } from '@/components/site/logo'

const KEY = 'aniko:intro-seen'
const STEPS = ['Initialising ANIKO core', 'Calibrating holographic display', 'Loading creative zones', 'Waking NIKO']

export function IntroSequence() {
  const { reducedMotion, play } = usePrefs()
  const [show, setShow] = useState(false)
  const [step, setStep] = useState(0)

  useEffect(() => {
    if (sessionStorage.getItem(KEY)) return
    setShow(true)
  }, [])

  useEffect(() => {
    if (!show) return
    const total = reducedMotion ? 900 : 3600
    const timers = STEPS.map((_, i) => setTimeout(() => setStep(i), (total / STEPS.length) * i))
    const done = setTimeout(() => finish(), total + 500)
    return () => {
      timers.forEach(clearTimeout)
      clearTimeout(done)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [show, reducedMotion])

  useEffect(() => {
    if (!show) return
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && finish()
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [show])

  function finish() {
    sessionStorage.setItem(KEY, '1')
    setShow(false)
    play('open')
  }

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          role="dialog"
          aria-modal="true"
          aria-label="ANIKO introduction"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 1.04, filter: 'blur(8px)' }}
          transition={{ duration: 0.7 }}
          className="fixed inset-0 z-[150] grid place-items-center overflow-hidden bg-[#0b0918] text-white"
        >
          <div aria-hidden="true" className="grid-bg absolute inset-0 opacity-40" />
          <motion.div
            aria-hidden="true"
            className="absolute size-[60vmin] rounded-full bg-[radial-gradient(circle,#a78bfa55,transparent_65%)] blur-2xl"
            animate={reducedMotion ? undefined : { scale: [0.8, 1.15, 1] }}
            transition={{ duration: 3 }}
          />
          <div className="relative flex flex-col items-center gap-8 px-6 text-center">
            <motion.div
              initial={{ scale: 0.6, opacity: 0, rotate: -40 }}
              animate={{ scale: 1, opacity: 1, rotate: 0 }}
              transition={{ duration: reducedMotion ? 0.1 : 1.1, ease: [0.2, 0.8, 0.2, 1] }}
            >
              <LogoMark className="size-24" />
            </motion.div>
            <motion.h1
              initial={{ letterSpacing: '1.2em', opacity: 0 }}
              animate={{ letterSpacing: '0.4em', opacity: 1 }}
              transition={{ duration: reducedMotion ? 0.1 : 1.4, delay: 0.3 }}
              className="font-display text-4xl font-medium md:text-6xl"
            >
              ANIKO
            </motion.h1>
            <p className="font-mono text-xs uppercase tracking-[0.3em] text-white/60" aria-live="polite">
              {STEPS[step]}
              <span className="animate-pulse">_</span>
            </p>
            <div className="h-px w-56 overflow-hidden bg-white/10">
              <motion.div
                className="h-full bg-gradient-to-r from-[#a78bfa] via-[#f472b6] to-[#67e8f9]"
                initial={{ width: '0%' }}
                animate={{ width: '100%' }}
                transition={{ duration: reducedMotion ? 0.9 : 3.6, ease: 'linear' }}
              />
            </div>
          </div>
          <button
            type="button"
            onClick={finish}
            autoFocus
            className="absolute bottom-8 right-8 rounded-full border border-white/20 px-4 py-2 font-mono text-xs uppercase tracking-[0.2em] text-white/80 transition-colors hover:border-white hover:text-white"
          >
            Skip intro
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
