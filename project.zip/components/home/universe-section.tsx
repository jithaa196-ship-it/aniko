'use client'

import dynamic from 'next/dynamic'
import Link from 'next/link'
import { useEffect, useState } from 'react'
import { ArrowUpRight } from 'lucide-react'
import { zones } from '@/lib/zones'
import { cn } from '@/lib/utils'

const UniverseScene = dynamic(() => import('./universe-scene'), {
  ssr: false,
  loading: () => <SceneLoading />,
})

function SceneLoading() {
  return (
    <div className="grid size-full place-items-center bg-[#0b0918]" role="status">
      <div className="flex flex-col items-center gap-3 text-white/70">
        <span className="size-10 animate-spin rounded-full border-2 border-white/15 border-t-[#a78bfa]" />
        <span className="font-mono text-xs uppercase tracking-[0.24em]">Rendering universe</span>
      </div>
    </div>
  )
}

function hasWebGL() {
  try {
    const c = document.createElement('canvas')
    return !!(c.getContext('webgl2') || c.getContext('webgl'))
  } catch {
    return false
  }
}

export function UniverseSection() {
  const [hovered, setHovered] = useState<string | null>(null)
  const [webgl, setWebgl] = useState<boolean | null>(null)
  useEffect(() => setWebgl(hasWebGL()), [])
  const active = zones.find((z) => z.id === hovered)

  return (
    <section id="universe" aria-labelledby="universe-title" className="scroll-mt-16 py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4 md:px-8">
        <div className="mb-10 flex flex-col justify-between gap-4 md:flex-row md:items-end">
          <div className="max-w-xl">
            <p className="eyebrow mb-4">01 — Navigation</p>
            <h2 id="universe-title" className="text-balance font-display text-3xl font-medium md:text-5xl">
              The 3D Universe
            </h2>
            <p className="mt-4 text-muted-foreground">
              Eight zones orbit the ANIKO core. Drag to rotate the system, hover a world to inspect it, click to travel.
            </p>
          </div>
          <p className="font-mono text-xs text-muted-foreground" aria-live="polite">
            {active ? `${active.index} / ${active.title} — ${active.description}` : 'Hover or focus a zone'}
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
          <div className="relative aspect-[4/3] overflow-hidden rounded-3xl border border-border bg-[#0b0918] md:aspect-[16/10]">
            {webgl === false ? (
              <div className="grid size-full place-items-center p-8 text-center text-sm text-white/70">
                3D is not available on this device. Use the zone list to navigate.
              </div>
            ) : webgl ? (
              <UniverseScene hovered={hovered} setHovered={setHovered} />
            ) : (
              <SceneLoading />
            )}
          </div>

          <nav aria-label="Universe zones">
            <ol className="grid grid-cols-2 gap-2 lg:grid-cols-1">
              {zones.map((z) => (
                <li key={z.id}>
                  <Link
                    href={z.href}
                    onMouseEnter={() => setHovered(z.id)}
                    onMouseLeave={() => setHovered(null)}
                    onFocus={() => setHovered(z.id)}
                    onBlur={() => setHovered(null)}
                    className={cn(
                      'group flex items-center gap-3 rounded-xl border px-3 py-2.5 text-sm transition-colors',
                      hovered === z.id ? 'border-primary bg-primary/10' : 'border-border bg-card hover:border-primary/50',
                    )}
                  >
                    <span aria-hidden="true" className="size-2.5 shrink-0 rounded-full" style={{ background: z.color, boxShadow: `0 0 12px ${z.color}` }} />
                    <span className="font-mono text-xs text-muted-foreground">{z.index}</span>
                    <span className="flex-1 truncate">{z.title}</span>
                    <ArrowUpRight className="size-4 opacity-40 transition-opacity group-hover:opacity-100" />
                  </Link>
                </li>
              ))}
            </ol>
          </nav>
        </div>
      </div>
    </section>
  )
}
