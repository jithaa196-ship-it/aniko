'use client'

import Link from 'next/link'
import { motion } from 'motion/react'
import { ArrowDown, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { usePrefs } from '@/components/providers/prefs-provider'
import { useUIStore } from '@/hooks/use-ui-store'
import { siteConfig } from '@/lib/site-config'

const words = ['Explore.', 'Experiment.', 'Evolve.']

export function Hero() {
  const { reducedMotion } = usePrefs()
  const { setNikoOpen } = useUIStore()
  const t = (delay: number) => ({ duration: reducedMotion ? 0 : 0.9, delay: reducedMotion ? 0 : delay, ease: [0.2, 0.8, 0.2, 1] as const })

  return (
    <section aria-labelledby="hero-title" className="relative isolate flex min-h-[92dvh] items-center overflow-hidden pt-24">
      <div aria-hidden="true" className="grid-bg absolute inset-0 -z-10" />
      <div aria-hidden="true" className="absolute -left-40 top-10 -z-10 size-[520px] rounded-full bg-glow-1/25 blur-[120px] animate-float" />
      <div aria-hidden="true" className="absolute -right-32 bottom-0 -z-10 size-[460px] rounded-full bg-glow-3/20 blur-[120px] animate-float [animation-delay:-3s]" />

      <div className="mx-auto w-full max-w-7xl px-4 md:px-8">
        <motion.p initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={t(0.1)} className="eyebrow mb-8 flex items-center gap-3">
          <span className="relative flex size-2">
            <span className="absolute inline-flex size-full animate-ping rounded-full bg-glow-3 opacity-75" />
            <span className="relative inline-flex size-2 rounded-full bg-glow-3" />
          </span>
          Experimental digital universe — v1.0
        </motion.p>

        <h1 id="hero-title" className="font-display text-[13vw] font-medium leading-[0.95] tracking-tight md:text-[8.5vw] xl:text-[128px]">
          <span className="sr-only">ANIKO — {siteConfig.tagline}</span>
          <span aria-hidden="true" className="flex flex-col">
            {words.map((w, i) => (
              <motion.span
                key={w}
                initial={{ opacity: 0, y: 40, filter: 'blur(10px)' }}
                animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                transition={t(0.2 + i * 0.15)}
                className={i === 1 ? 'text-gradient' : undefined}
              >
                {w}
              </motion.span>
            ))}
          </span>
        </h1>

        <div className="mt-10 flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={t(0.7)} className="max-w-md text-pretty text-lg leading-relaxed text-muted-foreground">
            {siteConfig.description}
          </motion.p>
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={t(0.85)} className="flex flex-wrap gap-3">
            <Button asChild size="lg" className="rounded-full px-6">
              <Link href="#universe">
                Enter the universe <ArrowDown className="size-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" className="rounded-full px-6" onClick={() => setNikoOpen(true)}>
              <Sparkles className="size-4" /> Ask NIKO
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
