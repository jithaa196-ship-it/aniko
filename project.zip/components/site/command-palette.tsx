'use client'

import { useRouter } from 'next/navigation'
import { useEffect } from 'react'
import { useTheme } from 'next-themes'
import {
  Box, Brush, FolderOpen, Gamepad2, Grid3x3, Home, Mail, Monitor, Moon, MousePointer2, Orbit, Palette, Sparkles, Sun,
  Type, User, Volume2, Wand2, Archive, Rewind,
} from 'lucide-react'
import {
  CommandDialog, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList, CommandSeparator, CommandShortcut,
} from '@/components/ui/command'
import { usePrefs } from '@/components/providers/prefs-provider'
import { useUIStore } from '@/hooks/use-ui-store'
import { projects } from '@/lib/projects'

const sections = [
  { label: 'Home', href: '/', icon: Home },
  { label: '3D Universe', href: '/#universe', icon: Orbit },
  { label: 'Creative Studio', href: '/studio', icon: Brush },
  { label: '3D Laboratory', href: '/lab', icon: Box },
  { label: 'NIKO AI', href: '/niko', icon: Sparkles },
  { label: 'Project Exhibition', href: '/projects', icon: FolderOpen },
  { label: 'Knowledge Archive', href: '/archive', icon: Archive },
  { label: 'Challenge Zone', href: '/challenges', icon: Gamepad2 },
  { label: 'Creator Hub', href: '/creator', icon: User },
  { label: 'Contact', href: '/contact', icon: Mail },
]

const tools = [
  { label: 'Colour Lab', tab: 'colour', icon: Palette },
  { label: 'Gradient Lab', tab: 'gradient', icon: Wand2 },
  { label: 'Typography Lab', tab: 'type', icon: Type },
  { label: 'UI Component Lab', tab: 'ui', icon: MousePointer2 },
  { label: 'Pattern Lab', tab: 'pattern', icon: Grid3x3 },
  { label: 'Experiment Saver', tab: 'saved', icon: FolderOpen },
]

export function CommandPalette() {
  const router = useRouter()
  const { setTheme } = useTheme()
  const { paletteOpen, setPaletteOpen, setNikoOpen } = useUIStore()
  const { soundOn, setSoundOn, setReducedMotionPref, reducedMotion, play } = usePrefs()

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault()
        setPaletteOpen(!paletteOpen)
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [paletteOpen, setPaletteOpen])

  const run = (fn: () => void) => {
    setPaletteOpen(false)
    play('tap')
    fn()
  }

  return (
    <CommandDialog open={paletteOpen} onOpenChange={setPaletteOpen} title="ANIKO Command Palette" description="Navigate, launch tools and change settings">
      <CommandInput placeholder="Type a command or search…" />
      <CommandList>
        <CommandEmpty>No matching commands.</CommandEmpty>
        <CommandGroup heading="Navigate">
          {sections.map((s) => (
            <CommandItem key={s.href} value={`go ${s.label}`} onSelect={() => run(() => router.push(s.href))}>
              <s.icon /> {s.label}
            </CommandItem>
          ))}
        </CommandGroup>
        <CommandGroup heading="Assistant">
          <CommandItem value="open niko ai chat assistant" onSelect={() => run(() => setNikoOpen(true))}>
            <Sparkles /> Open NIKO chat
            <CommandShortcut>AI</CommandShortcut>
          </CommandItem>
        </CommandGroup>
        <CommandGroup heading="Creative tools">
          {tools.map((t) => (
            <CommandItem key={t.tab} value={`launch ${t.label}`} onSelect={() => run(() => router.push(`/studio?tool=${t.tab}`))}>
              <t.icon /> {t.label}
            </CommandItem>
          ))}
        </CommandGroup>
        <CommandGroup heading="Projects">
          {projects.map((p) => (
            <CommandItem key={p.slug} value={`project ${p.title} ${p.category}`} onSelect={() => run(() => router.push(`/projects/${p.slug}`))}>
              <FolderOpen /> {p.title}
            </CommandItem>
          ))}
        </CommandGroup>
        <CommandSeparator />
        <CommandGroup heading="Settings">
          <CommandItem value="theme dark" onSelect={() => run(() => setTheme('dark'))}>
            <Moon /> Dark theme
          </CommandItem>
          <CommandItem value="theme light" onSelect={() => run(() => setTheme('light'))}>
            <Sun /> Light theme
          </CommandItem>
          <CommandItem value="theme system" onSelect={() => run(() => setTheme('system'))}>
            <Monitor /> System theme
          </CommandItem>
          <CommandItem value="toggle sound effects" onSelect={() => run(() => setSoundOn(!soundOn))}>
            <Volume2 /> {soundOn ? 'Turn sound off' : 'Turn sound on'}
          </CommandItem>
          <CommandItem value="toggle reduced motion" onSelect={() => run(() => setReducedMotionPref(reducedMotion ? 'off' : 'on'))}>
            <Rewind /> {reducedMotion ? 'Allow motion' : 'Reduce motion'}
          </CommandItem>
          <CommandItem
            value="replay introduction intro"
            onSelect={() =>
              run(() => {
                sessionStorage.removeItem('aniko:intro-seen')
                window.location.href = '/'
              })
            }
          >
            <Sparkles /> Replay introduction
          </CommandItem>
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  )
}
