import { cn } from '@/lib/utils'

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 40 40" aria-hidden="true" className={cn('size-8', className)}>
      <defs>
        <linearGradient id="aniko-mark" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="var(--glow-1)" />
          <stop offset=".55" stopColor="var(--glow-2)" />
          <stop offset="1" stopColor="var(--glow-3)" />
        </linearGradient>
      </defs>
      <circle cx="20" cy="20" r="18" fill="none" stroke="currentColor" strokeOpacity=".15" />
      <path d="M20 6 33 31H7Z" fill="none" stroke="url(#aniko-mark)" strokeWidth="2.2" strokeLinejoin="round" />
      <circle cx="20" cy="23.5" r="4.5" fill="url(#aniko-mark)" />
    </svg>
  )
}

export function Logo({ className }: { className?: string }) {
  return (
    <span className={cn('inline-flex items-center gap-2.5', className)}>
      <LogoMark />
      <span className="font-display text-base font-medium tracking-[0.32em]">ANIKO</span>
    </span>
  )
}
