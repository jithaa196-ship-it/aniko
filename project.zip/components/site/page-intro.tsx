export function PageIntro({
  index,
  eyebrow,
  title,
  description,
  children,
}: {
  index?: string
  eyebrow: string
  title: string
  description: string
  children?: React.ReactNode
}) {
  return (
    <header className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
      <div className="max-w-2xl">
        <p className="eyebrow mb-4 flex items-center gap-3">
          {index && <span className="font-mono text-primary">{index}</span>}
          <span aria-hidden="true" className="h-px w-8 bg-border" />
          {eyebrow}
        </p>
        <h1 className="text-balance font-display text-4xl font-medium leading-[1.05] md:text-6xl">{title}</h1>
        <p className="mt-4 text-pretty text-base leading-relaxed text-muted-foreground md:text-lg">{description}</p>
      </div>
      {children}
    </header>
  )
}
