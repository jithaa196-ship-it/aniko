'use client'

import { useEffect } from 'react'
import { toast } from 'sonner'
import { usePrefs } from '@/components/providers/prefs-provider'
import { useLocalStorage } from '@/hooks/use-local-storage'

const KONAMI = ['ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight', 'b', 'a']

/**
 * Hidden easter eggs:
 * 1. Konami code toggles "hyperspace" hue shift.
 * 2. Typing "niko" anywhere outside inputs makes NIKO say hi.
 * 3. Clicking the logo five times quickly reveals a secret message.
 */
export function EasterEggs() {
  const { play } = usePrefs()
  const [found, setFound] = useLocalStorage<string[]>('aniko:eggs', [])

  useEffect(() => {
    let seq: string[] = []
    let typed = ''
    const discover = (id: string, message: string) => {
      play('success')
      toast(message, { description: found.includes(id) ? 'Already discovered.' : `Easter egg ${new Set([...found, id]).size}/3 found.` })
      if (!found.includes(id)) setFound((prev) => [...prev, id])
    }
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement
      if (t.closest('input, textarea, [contenteditable="true"]')) return
      seq = [...seq, e.key].slice(-KONAMI.length)
      if (seq.join(',') === KONAMI.join(',')) {
        document.documentElement.classList.toggle('hyperspace')
        discover('konami', 'Hyperspace mode toggled. Enter the code again to return.')
      }
      typed = (typed + e.key.toLowerCase()).slice(-4)
      if (typed === 'niko') discover('niko', 'NIKO: "You called? I am always listening for my name."')
    }
    let clicks = 0
    let timer: ReturnType<typeof setTimeout>
    const onClick = (e: MouseEvent) => {
      if (!(e.target as HTMLElement).closest('[data-logo]')) return
      clicks++
      clearTimeout(timer)
      timer = setTimeout(() => (clicks = 0), 1200)
      if (clicks >= 5) {
        clicks = 0
        discover('logo', 'Secret signal decoded: "Explore. Experiment. Evolve." — keep making things.')
      }
    }
    window.addEventListener('keydown', onKey)
    window.addEventListener('click', onClick)
    return () => {
      window.removeEventListener('keydown', onKey)
      window.removeEventListener('click', onClick)
      clearTimeout(timer)
    }
  }, [found, setFound, play])

  return null
}
