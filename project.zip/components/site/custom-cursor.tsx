'use client'

import { useEffect, useRef, useState } from 'react'
import { usePrefs } from '@/components/providers/prefs-provider'

export function CustomCursor() {
  const { customCursor, reducedMotion } = usePrefs()
  const dot = useRef<HTMLDivElement>(null)
  const ring = useRef<HTMLDivElement>(null)
  const [enabled, setEnabled] = useState(false)

  useEffect(() => {
    const fine = window.matchMedia('(pointer: fine)').matches
    const on = customCursor && fine && !reducedMotion
    setEnabled(on)
    document.documentElement.classList.toggle('custom-cursor', on)
    return () => document.documentElement.classList.remove('custom-cursor')
  }, [customCursor, reducedMotion])

  useEffect(() => {
    if (!enabled) return
    let x = -100
    let y = -100
    let rx = x
    let ry = y
    let raf = 0
    const move = (e: PointerEvent) => {
      x = e.clientX
      y = e.clientY
      const target = e.target as HTMLElement | null
      const interactive = !!target?.closest('a, button, [role="button"], input, select, textarea, label, [data-cursor]')
      ring.current?.setAttribute('data-hover', String(interactive))
    }
    const loop = () => {
      rx += (x - rx) * 0.18
      ry += (y - ry) * 0.18
      if (dot.current) dot.current.style.transform = `translate3d(${x}px, ${y}px, 0)`
      if (ring.current) ring.current.style.transform = `translate3d(${rx}px, ${ry}px, 0)`
      raf = requestAnimationFrame(loop)
    }
    window.addEventListener('pointermove', move)
    raf = requestAnimationFrame(loop)
    return () => {
      window.removeEventListener('pointermove', move)
      cancelAnimationFrame(raf)
    }
  }, [enabled])

  if (!enabled) return null
  return (
    <div aria-hidden="true" className="pointer-events-none fixed inset-0 z-[200]">
      <div ref={dot} className="absolute -left-1 -top-1 size-2 rounded-full bg-primary" />
      <div
        ref={ring}
        className="absolute -left-4 -top-4 size-8 rounded-full border border-primary/60 transition-[width,height,margin,background-color] duration-200 data-[hover=true]:-left-6 data-[hover=true]:-top-6 data-[hover=true]:size-12 data-[hover=true]:bg-primary/10"
      />
    </div>
  )
}
