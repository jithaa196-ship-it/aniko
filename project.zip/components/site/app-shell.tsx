'use client'

import { ThemeProvider } from 'next-themes'
import { Toaster } from '@/components/ui/sonner'
import { TooltipProvider } from '@/components/ui/tooltip'
import { PrefsProvider } from '@/components/providers/prefs-provider'
import { CommandPalette } from './command-palette'
import { CustomCursor } from './custom-cursor'
import { EasterEggs } from './easter-eggs'
import { SiteFooter } from './site-footer'
import { SiteHeader } from './site-header'
import { ScrollToTop } from './scroll-to-top'
import { NikoLauncher } from '@/components/niko/niko-launcher'

export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <ThemeProvider attribute="class" defaultTheme="dark" enableSystem disableTransitionOnChange>
      <PrefsProvider>
        <TooltipProvider>
          <a
            href="#main"
            className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-md focus:bg-primary focus:px-4 focus:py-2 focus:text-primary-foreground"
          >
            Skip to content
          </a>
          <SiteHeader />
          <main id="main" className="relative min-h-dvh">
            {children}
          </main>
          <SiteFooter />
          <CommandPalette />
          <NikoLauncher />
          <ScrollToTop />
          <CustomCursor />
          <EasterEggs />
          <Toaster position="bottom-left" />
        </TooltipProvider>
      </PrefsProvider>
    </ThemeProvider>
  )
}
