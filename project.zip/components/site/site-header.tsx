'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useEffect, useState } from 'react'
import { Command, Menu, Volume2, VolumeX } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet'
import { usePrefs } from '@/components/providers/prefs-provider'
import { useUIStore } from '@/hooks/use-ui-store'
import { navItems } from '@/lib/zones'
import { cn } from '@/lib/utils'
import { Logo } from './logo'
import { ThemeToggle } from './theme-toggle'

function useActiveHref() {
  const pathname = usePathname()
  const [hash, setHash] = useState('')

  useEffect(() => {
    if (pathname !== '/') {
      setHash('')
      return
    }
    const el = document.getElementById('universe')
    if (!el) return
    const io = new IntersectionObserver(([entry]) => setHash(entry.isIntersecting ? '#universe' : ''), {
      rootMargin: '-40% 0px -40% 0px',
    })
    io.observe(el)
    return () => io.disconnect()
  }, [pathname])

  return (href: string) => {
    if (href === '/#universe') return pathname === '/' && hash === '#universe'
    if (href === '/') return pathname === '/' && hash !== '#universe'
    return pathname === href || pathname.startsWith(`${href}/`) || (href === '/studio' && pathname === '/lab')
  }
}

export function SiteHeader() {
  const isActive = useActiveHref()
  const { setPaletteOpen } = useUIStore()
  const { soundOn, setSoundOn, play } = usePrefs()
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header
      className={cn(
        'fixed inset-x-0 top-0 z-50 transition-colors duration-300',
        scrolled ? 'border-b border-border bg-background/75 backdrop-blur-xl' : 'bg-transparent',
      )}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 md:px-8">
        <Link href="/" className="rounded-md text-foreground" aria-label="ANIKO home" data-logo>
          <Logo />
        </Link>

        <nav aria-label="Primary" className="hidden lg:block">
          <ul className="flex items-center gap-1 rounded-full border border-border bg-card/60 p-1 backdrop-blur-xl">
            {navItems.map((item) => {
              const active = isActive(item.href)
              return (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    aria-current={active ? 'page' : undefined}
                    onClick={() => play('tap')}
                    className={cn(
                      'block rounded-full px-3 py-1.5 text-sm transition-colors',
                      active ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground',
                    )}
                  >
                    {item.label}
                  </Link>
                </li>
              )
            })}
          </ul>
        </nav>

        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setPaletteOpen(true)}
            className="hidden gap-2 text-muted-foreground sm:inline-flex"
            aria-label="Open command palette"
          >
            <Command className="size-4" />
            <kbd className="font-mono text-xs">K</kbd>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            aria-label={soundOn ? 'Turn sound effects off' : 'Turn sound effects on'}
            aria-pressed={soundOn}
            onClick={() => setSoundOn(!soundOn)}
          >
            {soundOn ? <Volume2 className="size-4" /> : <VolumeX className="size-4" />}
          </Button>
          <ThemeToggle />
          <Button variant="ghost" size="icon" className="lg:hidden" aria-label="Open navigation menu" onClick={() => setOpen(true)}>
            <Menu className="size-5" />
          </Button>
        </div>
      </div>

      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent side="right" className="w-[85vw] max-w-sm">
          <SheetHeader>
            <SheetTitle className="font-display tracking-[0.2em]">Command Centre</SheetTitle>
          </SheetHeader>
          <nav aria-label="Mobile" className="px-4">
            <ul className="flex flex-col gap-1">
              {navItems.map((item, i) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    onClick={() => setOpen(false)}
                    aria-current={isActive(item.href) ? 'page' : undefined}
                    className={cn(
                      'flex items-center justify-between rounded-lg px-3 py-3 text-base transition-colors',
                      isActive(item.href) ? 'bg-primary/15 text-foreground' : 'text-muted-foreground hover:bg-muted hover:text-foreground',
                    )}
                  >
                    {item.label}
                    <span className="font-mono text-xs opacity-60">{String(i + 1).padStart(2, '0')}</span>
                  </Link>
                </li>
              ))}
            </ul>
            <Button
              variant="outline"
              className="mt-6 w-full gap-2"
              onClick={() => {
                setOpen(false)
                setPaletteOpen(true)
              }}
            >
              <Command className="size-4" /> Open command palette
            </Button>
          </nav>
        </SheetContent>
      </Sheet>
    </header>
  )
}
