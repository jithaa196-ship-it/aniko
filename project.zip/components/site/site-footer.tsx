'use client'

import Link from 'next/link'
import { usePrefs } from '@/components/providers/prefs-provider'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { navItems } from '@/lib/zones'
import { githubUrl, siteConfig } from '@/lib/site-config'
import { Logo } from './logo'

export function SiteFooter() {
  const { reducedMotion, setReducedMotionPref, customCursor, setCustomCursor } = usePrefs()
  const socials = [
    githubUrl && { label: 'GitHub', href: githubUrl },
    siteConfig.links.linkedin && { label: 'LinkedIn', href: siteConfig.links.linkedin },
    siteConfig.links.email && { label: 'Email', href: `mailto:${siteConfig.links.email}` },
  ].filter(Boolean) as { label: string; href: string }[]

  return (
    <footer className="relative border-t border-border">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 md:grid-cols-[1.4fr_1fr_1fr] md:px-8">
        <div className="flex flex-col gap-4">
          <Logo />
          <p className="max-w-sm text-sm leading-relaxed text-muted-foreground">{siteConfig.description}</p>
          <p className="font-display text-sm tracking-[0.2em] text-gradient">{siteConfig.tagline}</p>
        </div>
        <nav aria-label="Footer">
          <p className="eyebrow mb-4">Navigate</p>
          <ul className="grid grid-cols-2 gap-2 text-sm">
            {navItems.map((n) => (
              <li key={n.href}>
                <Link href={n.href} className="text-muted-foreground transition-colors hover:text-foreground">
                  {n.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        <div className="flex flex-col gap-4">
          <p className="eyebrow">Experience</p>
          <div className="flex items-center justify-between gap-4">
            <Label htmlFor="pref-motion" className="text-sm text-muted-foreground">Reduced motion</Label>
            <Switch id="pref-motion" checked={reducedMotion} onCheckedChange={(v) => setReducedMotionPref(v ? 'on' : 'off')} />
          </div>
          <div className="flex items-center justify-between gap-4">
            <Label htmlFor="pref-cursor" className="text-sm text-muted-foreground">Custom cursor</Label>
            <Switch id="pref-cursor" checked={customCursor} onCheckedChange={setCustomCursor} />
          </div>
          {socials.length > 0 && (
            <ul className="flex gap-4 pt-2 text-sm">
              {socials.map((s) => (
                <li key={s.label}>
                  <a href={s.href} target="_blank" rel="noreferrer" className="text-muted-foreground hover:text-foreground">
                    {s.label}
                  </a>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
      <div className="border-t border-border">
        <div className="mx-auto flex max-w-7xl flex-col justify-between gap-2 px-4 py-5 text-xs text-muted-foreground md:flex-row md:px-8">
          <p>
            © {new Date().getFullYear()} {siteConfig.creator.name}. Built as ANIKO.
          </p>
          <p className="font-mono">Press Ctrl / ⌘ + K to open the Command Centre</p>
        </div>
      </div>
    </footer>
  )
}
