'use client'

import { ArrowUp } from 'lucide-react'
import { useEffect, useState } from 'react'
import { usePrefs } from '@/components/providers/prefs-provider'
import { cn } from '@/lib/utils'

export function ScrollToTop() {
  const [visible, setVisible] = useState(false)
  const { reducedMotion } = usePrefs()

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 600)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <button
      type="button"
      aria-label="Scroll to top"
      onClick={() => window.scrollTo({ top: 0, behavior: reducedMotion ? 'auto' : 'smooth' })}
      className={cn(
        'glass fixed bottom-24 right-5 z-40 grid size-11 place-items-center rounded-full text-foreground transition-all duration-300 hover:border-primary md:right-8',
        visible ? 'translate-y-0 opacity-100' : 'pointer-events-none translate-y-4 opacity-0',
      )}
      tabIndex={visible ? 0 : -1}
    >
      <ArrowUp className="size-4" />
    </button>
  )
}
