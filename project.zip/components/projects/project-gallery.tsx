'use client'

import Image from 'next/image'
import Link from 'next/link'
import { useMemo, useState } from 'react'
import { Search } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { projectCategories, projects, type ProjectCategory } from '@/lib/projects'
import { cn } from '@/lib/utils'

export function ProjectGallery() {
  const [cat, setCat] = useState<'All' | ProjectCategory>('All')
  const [q, setQ] = useState('')

  const list = useMemo(() => {
    const term = q.trim().toLowerCase()
    return projects.filter(
      (p) =>
        (cat === 'All' || p.category === cat) &&
        (!term || [p.title, p.summary, ...p.tools].some((s) => s.toLowerCase().includes(term))),
    )
  }, [cat, q])

  return (
    <div className="flex flex-col gap-8">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div role="radiogroup" aria-label="Filter by category" className="flex flex-wrap gap-1">
          {(['All', ...projectCategories] as const).map((c) => (
            <button
              key={c}
              type="button"
              role="radio"
              aria-checked={cat === c}
              onClick={() => setCat(c)}
              className={cn('rounded-full border px-3.5 py-1.5 text-sm transition-colors', cat === c ? 'border-primary bg-primary text-primary-foreground' : 'border-border hover:border-primary/50')}
            >
              {c}
            </button>
          ))}
        </div>
        <div className="relative md:w-72">
          <Search aria-hidden="true" className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input aria-label="Search projects" placeholder="Search projects or tools" value={q} onChange={(e) => setQ(e.target.value)} className="pl-9" />
        </div>
      </div>

      <p className="text-sm text-muted-foreground" aria-live="polite">{list.length} project{list.length === 1 ? '' : 's'}</p>

      {list.length === 0 ? (
        <p className="rounded-3xl border border-dashed border-border p-12 text-center text-muted-foreground">No projects match that search.</p>
      ) : (
        <ul className="grid gap-x-6 gap-y-12 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((p) => (
            <li key={p.slug}>
              <Link href={`/projects/${p.slug}`} className="group block">
                <div className="relative aspect-[4/3] overflow-hidden rounded-2xl border border-border">
                  <Image src={p.cover} alt="" fill sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw" className="object-cover transition-transform duration-700 group-hover:scale-105" />
                  {p.isPlaceholder && (
                    <span className="absolute left-3 top-3 rounded-full bg-background/85 px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider backdrop-blur">Sample slot</span>
                  )}
                </div>
                <div className="mt-4 flex items-center justify-between font-mono text-xs text-muted-foreground">
                  <span>{p.category}</span>
                  <span>{p.status}</span>
                </div>
                <h2 className="mt-1.5 font-display text-xl group-hover:text-primary">{p.title}</h2>
                <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{p.summary}</p>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
