'use client'

import { useMemo, useState } from 'react'
import { Download, Pencil, Plus, Search, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { useLocalStorage } from '@/hooks/use-local-storage'
import { archiveCategories, starterEntries, type ArchiveCategory, type ArchiveEntry } from '@/lib/archive'
import { downloadDataUrl } from '@/lib/export'
import { cn } from '@/lib/utils'

type Draft = Omit<ArchiveEntry, 'id' | 'createdAt'> & { id?: string }
const empty: Draft = { title: '', category: 'Creative ideas', body: '', tags: [], images: [] }

export function Archive() {
  const [entries, setEntries] = useLocalStorage<ArchiveEntry[]>('aniko:archive', starterEntries)
  const [cat, setCat] = useState<'All' | ArchiveCategory>('All')
  const [q, setQ] = useState('')
  const [draft, setDraft] = useState<Draft | null>(null)
  const [tagText, setTagText] = useState('')
  const [error, setError] = useState('')

  const list = useMemo(() => {
    const t = q.trim().toLowerCase()
    return entries.filter((e) => (cat === 'All' || e.category === cat) && (!t || [e.title, e.body, ...e.tags].some((s) => s.toLowerCase().includes(t))))
  }, [entries, cat, q])

  const open = (d: Draft) => {
    setDraft(d)
    setTagText(d.tags.join(', '))
    setError('')
  }

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!draft) return
    if (!draft.title.trim() || !draft.body.trim()) return setError('Title and note are both required.')
    const tags = tagText.split(',').map((t) => t.trim().toLowerCase()).filter(Boolean).slice(0, 8)
    const images = draft.images.filter((u) => /^https?:\/\//.test(u) || u.startsWith('/'))
    if (draft.id) {
      setEntries((prev) => prev.map((x) => (x.id === draft.id ? { ...x, ...draft, tags, images, id: x.id } : x)))
    } else {
      setEntries((prev) => [{ ...draft, tags, images, id: crypto.randomUUID(), createdAt: new Date().toISOString() }, ...prev])
    }
    setDraft(null)
  }

  const exportJson = () => {
    const url = URL.createObjectURL(new Blob([JSON.stringify(entries, null, 2)], { type: 'application/json' }))
    downloadDataUrl(url, 'aniko-archive.json')
    URL.revokeObjectURL(url)
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[240px_1fr]">
      <aside className="flex flex-col gap-4">
        <Button onClick={() => open(empty)}><Plus className="size-4" /> New entry</Button>
        <nav aria-label="Archive categories">
          <ul className="flex flex-wrap gap-1 lg:flex-col">
            {(['All', ...archiveCategories] as const).map((c) => {
              const count = c === 'All' ? entries.length : entries.filter((e) => e.category === c).length
              return (
                <li key={c}>
                  <button
                    type="button"
                    aria-pressed={cat === c}
                    onClick={() => setCat(c)}
                    className={cn('flex w-full items-center justify-between gap-3 rounded-lg px-3 py-2 text-left text-sm transition-colors', cat === c ? 'bg-primary/10 text-primary' : 'text-muted-foreground hover:bg-muted hover:text-foreground')}
                  >
                    {c} <span className="font-mono text-xs">{count}</span>
                  </button>
                </li>
              )
            })}
          </ul>
        </nav>
        <Button variant="outline" size="sm" onClick={exportJson}><Download className="size-4" /> Export archive</Button>
      </aside>

      <div className="flex flex-col gap-6">
        <div className="relative">
          <Search aria-hidden="true" className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input aria-label="Search archive" placeholder="Search notes, tags and ideas" value={q} onChange={(e) => setQ(e.target.value)} className="pl-9" />
        </div>
        {list.length === 0 ? (
          <p className="rounded-3xl border border-dashed border-border p-12 text-center text-muted-foreground">Nothing archived here yet.</p>
        ) : (
          <ul className="columns-1 gap-4 md:columns-2 [&>li]:mb-4">
            {list.map((e) => (
              <li key={e.id} className="glass break-inside-avoid rounded-2xl p-5">
                <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{e.category} · {new Date(e.createdAt).toLocaleDateString()}</p>
                <h2 className="mt-2 font-display text-lg">{e.title}</h2>
                {e.images[0] && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={e.images[0]} alt="" className="mt-3 aspect-video w-full rounded-xl object-cover" />
                )}
                <p className="mt-3 whitespace-pre-line text-sm leading-relaxed text-muted-foreground">{e.body}</p>
                {e.tags.length > 0 && (
                  <ul className="mt-4 flex flex-wrap gap-1.5">
                    {e.tags.map((t) => (
                      <li key={t}><button type="button" onClick={() => setQ(t)} className="rounded-full bg-muted px-2 py-0.5 font-mono text-[11px] hover:bg-primary/15">#{t}</button></li>
                    ))}
                  </ul>
                )}
                <div className="mt-4 flex justify-end gap-1">
                  <Button variant="ghost" size="icon" aria-label={`Edit ${e.title}`} onClick={() => open(e)}><Pencil className="size-4" /></Button>
                  <Button variant="ghost" size="icon" aria-label={`Delete ${e.title}`} onClick={() => setEntries((p) => p.filter((x) => x.id !== e.id))}><Trash2 className="size-4" /></Button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      <Dialog open={!!draft} onOpenChange={(o) => !o && setDraft(null)}>
        <DialogContent>
          {draft && (
            <form onSubmit={submit} className="flex flex-col gap-4">
              <DialogHeader>
                <DialogTitle>{draft.id ? 'Edit entry' : 'New archive entry'}</DialogTitle>
                <DialogDescription>Saved to this browser only.</DialogDescription>
              </DialogHeader>
              <div className="flex flex-col gap-2">
                <Label htmlFor="a-title">Title</Label>
                <Input id="a-title" value={draft.title} maxLength={120} onChange={(e) => setDraft({ ...draft, title: e.target.value })} />
              </div>
              <div className="flex flex-col gap-2">
                <Label htmlFor="a-cat">Category</Label>
                <select id="a-cat" value={draft.category} onChange={(e) => setDraft({ ...draft, category: e.target.value as ArchiveCategory })} className="h-9 rounded-md border border-border bg-background px-3 text-sm">
                  {archiveCategories.map((c) => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div className="flex flex-col gap-2">
                <Label htmlFor="a-body">Note</Label>
                <Textarea id="a-body" rows={5} maxLength={4000} value={draft.body} onChange={(e) => setDraft({ ...draft, body: e.target.value })} />
              </div>
              <div className="flex flex-col gap-2">
                <Label htmlFor="a-tags">Tags (comma separated)</Label>
                <Input id="a-tags" value={tagText} onChange={(e) => setTagText(e.target.value)} />
              </div>
              <div className="flex flex-col gap-2">
                <Label htmlFor="a-img">Image URL (optional)</Label>
                <Input id="a-img" type="url" placeholder="https://" value={draft.images[0] ?? ''} onChange={(e) => setDraft({ ...draft, images: e.target.value ? [e.target.value] : [] })} />
              </div>
              {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setDraft(null)}>Cancel</Button>
                <Button type="submit">Save entry</Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
