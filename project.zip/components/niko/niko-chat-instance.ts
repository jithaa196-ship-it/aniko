'use client'

import { Chat } from '@ai-sdk/react'
import type { UIMessage } from 'ai'

/** One shared conversation so the floating panel and /niko page keep the same memory. */
export const nikoChat = new Chat<UIMessage>({})
