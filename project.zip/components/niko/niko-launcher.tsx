'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Maximize2 } from 'lucide-react'
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from '@/components/ui/sheet'
import { useUIStore } from '@/hooks/use-ui-store'
import { NikoAvatar } from './niko-avatar'
import { NikoConversation } from './niko-conversation'

export function NikoLauncher() {
  const pathname = usePathname()
  const { nikoOpen, setNikoOpen } = useUIStore()
  if (pathname === '/niko') return null

  return (
    <>
      <button
        type="button"
        onClick={() => setNikoOpen(true)}
        aria-label="Chat with NIKO, the AI assistant"
        className="glass fixed bottom-5 right-5 z-40 flex items-center gap-2 rounded-full py-1.5 pl-1.5 pr-4 text-sm shadow-lg transition-transform hover:scale-105 md:right-8"
      >
        <NikoAvatar className="size-9 text-xs" />
        <span className="font-medium">NIKO</span>
      </button>

      <Sheet open={nikoOpen} onOpenChange={setNikoOpen}>
        <SheetContent side="right" className="flex w-full flex-col gap-0 p-0 sm:max-w-md">
          <SheetHeader className="flex-row items-center gap-3 border-b border-border p-4 pr-12">
            <NikoAvatar className="size-9 text-xs" />
            <div className="flex-1">
              <SheetTitle className="font-display text-base">NIKO</SheetTitle>
              <SheetDescription className="text-xs">Holographic guide of ANIKO</SheetDescription>
            </div>
            <Link
              href="/niko"
              onClick={() => setNikoOpen(false)}
              aria-label="Open full NIKO page"
              className="grid size-8 place-items-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground"
            >
              <Maximize2 className="size-4" />
            </Link>
          </SheetHeader>
          <NikoConversation compact onNavigate={() => setNikoOpen(false)} />
        </SheetContent>
      </Sheet>
    </>
  )
}
