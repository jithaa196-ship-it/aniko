import { cn } from '@/lib/utils'

/** Holographic orb avatar. `state` drives the animation. */
export function NikoAvatar({
  state = 'idle',
  className,
}: {
  state?: 'idle' | 'thinking' | 'speaking'
  className?: string
}) {
  return (
    <span aria-hidden="true" data-state={state} className={cn('niko-orb relative inline-grid size-10 place-items-center', className)}>
      <span className="absolute inset-0 rounded-full bg-[conic-gradient(from_0deg,var(--glow-1),var(--glow-2),var(--glow-3),var(--glow-1))] opacity-80 blur-[6px] niko-spin" />
      <span className="absolute inset-[3px] rounded-full bg-background" />
      <span className="absolute inset-[18%] rounded-full bg-[radial-gradient(circle_at_35%_30%,var(--glow-3),var(--glow-1)_55%,transparent_75%)] niko-pulse" />
      <span className="relative flex gap-[18%] w-[46%] justify-center">
        <span className="niko-eye h-[0.35em] w-[0.22em] rounded-full bg-foreground" />
        <span className="niko-eye h-[0.35em] w-[0.22em] rounded-full bg-foreground" />
      </span>
    </span>
  )
}
