'use client'

import Link from 'next/link'
import { useEffect, useRef, useState } from 'react'
import { useChat } from '@ai-sdk/react'
import type { UIMessage } from 'ai'
import { ArrowUp, RotateCcw, Square, WifiOff } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { usePrefs } from '@/components/providers/prefs-provider'
import { guidedReply, suggestedQuestions } from '@/lib/niko-knowledge'
import { cn } from '@/lib/utils'
import { NikoAvatar } from './niko-avatar'
import { nikoChat } from './niko-chat-instance'

const ROUTES: Record<string, string> = {
  '/': 'Home',
  '/#universe': '3D Universe',
  '/studio': 'Creative Studio',
  '/lab': '3D Laboratory',
  '/niko': 'NIKO AI',
  '/projects': 'Projects',
  '/archive': 'Knowledge Archive',
  '/challenges': 'Challenge Zone',
  '/creator': 'Creator Hub',
  '/creator#skills': 'Skills Universe',
  '/creator#github': 'GitHub',
  '/contact': 'Contact',
}

function textOf(m: UIMessage) {
  return m.parts.map((p) => (p.type === 'text' ? p.text : '')).join('')
}

function linksIn(text: string) {
  const found = new Set<string>()
  const re = /(?:^|[\s(`"'])(\/(?:[a-z#-]+)?(?:\/[a-z0-9-]+)?)/gi
  for (const m of text.matchAll(re)) {
    const path = m[1].replace(/[.,)]+$/, '')
    if (ROUTES[path] || path.startsWith('/projects/')) found.add(path)
  }
  return [...found].slice(0, 4)
}

function MessageText({ text }: { text: string }) {
  return (
    <div className="flex flex-col gap-2">
      {text.split(/\n{2,}/).map((para, i) => (
        <p key={i} className="whitespace-pre-wrap leading-relaxed">
          {para.split(/(\*\*[^*]+\*\*)/g).map((chunk, j) =>
            chunk.startsWith('**') && chunk.endsWith('**') ? <strong key={j}>{chunk.slice(2, -2)}</strong> : chunk,
          )}
        </p>
      ))}
    </div>
  )
}

export function NikoConversation({ compact = false, onNavigate }: { compact?: boolean; onNavigate?: () => void }) {
  const { messages, sendMessage, status, error, setMessages, stop, clearError } = useChat({ chat: nikoChat })
  const [input, setInput] = useState('')
  const [guided, setGuided] = useState(false)
  const scroller = useRef<HTMLDivElement>(null)
  const { play } = usePrefs()
  const busy = status === 'submitted' || status === 'streaming'

  useEffect(() => {
    if (error) {
      setGuided(true)
      play('error')
    }
  }, [error, play])

  useEffect(() => {
    scroller.current?.scrollTo({ top: scroller.current.scrollHeight, behavior: 'smooth' })
  }, [messages, status])

  const ask = (raw: string) => {
    const text = raw.trim().slice(0, 1000)
    if (!text || busy) return
    setInput('')
    play('tap')
    if (guided) {
      const reply = guidedReply(text)
      const suffix = reply.links?.length ? `\n\n${reply.links.map((l) => l.href).join(' ')}` : ''
      setMessages((prev) => [
        ...prev,
        { id: crypto.randomUUID(), role: 'user', parts: [{ type: 'text', text }] },
        { id: crypto.randomUUID(), role: 'assistant', parts: [{ type: 'text', text: reply.text + suffix }] },
      ])
      return
    }
    sendMessage({ text })
  }

  const retryAI = () => {
    clearError()
    setGuided(false)
  }

  const state = status === 'submitted' ? 'thinking' : status === 'streaming' ? 'speaking' : 'idle'
  const lastIsUser = messages.at(-1)?.role === 'user'

  return (
    <div className="flex h-full min-h-0 flex-col">
      {guided && (
        <div role="status" className="flex items-center justify-between gap-3 border-b border-border bg-accent/10 px-4 py-2 text-xs">
          <span className="flex items-center gap-2 text-muted-foreground">
            <WifiOff className="size-3.5" /> AI service unavailable — NIKO is in guided mode.
          </span>
          <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={retryAI}>
            Retry AI
          </Button>
        </div>
      )}

      <div ref={scroller} className="min-h-0 flex-1 overflow-y-auto px-4 py-5" aria-live="polite" aria-busy={busy}>
        {messages.length === 0 ? (
          <div className="flex flex-col items-center gap-4 py-6 text-center">
            <NikoAvatar className={compact ? 'size-14' : 'size-20 text-2xl'} />
            <div>
              <p className="font-display text-lg">{"Hi, I'm NIKO."}</p>
              <p className="mt-1 max-w-sm text-sm text-muted-foreground">
                The lab assistant of ANIKO. Ask me about the zones, the projects, the creator, or design tools.
              </p>
            </div>
            <ul className="flex flex-wrap justify-center gap-2" aria-label="Suggested questions">
              {suggestedQuestions.slice(0, compact ? 4 : 6).map((q) => (
                <li key={q}>
                  <button
                    type="button"
                    onClick={() => ask(q)}
                    className="rounded-full border border-border bg-card px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:border-primary hover:text-foreground"
                  >
                    {q}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        ) : (
          <ol className="flex flex-col gap-4">
            {messages.map((m) => {
              const text = textOf(m)
              const isUser = m.role === 'user'
              const links = isUser ? [] : linksIn(text)
              return (
                <li key={m.id} className={cn('flex gap-3', isUser && 'flex-row-reverse')}>
                  {!isUser && <NikoAvatar className="size-7 shrink-0 text-[10px]" />}
                  <div
                    className={cn(
                      'max-w-[85%] rounded-2xl px-4 py-2.5 text-sm',
                      isUser ? 'rounded-br-sm bg-primary text-primary-foreground' : 'rounded-bl-sm border border-border bg-card',
                    )}
                  >
                    <span className="sr-only">{isUser ? 'You said:' : 'NIKO said:'}</span>
                    <MessageText text={text.replace(/\n\n(\/[^\s]+\s?)+$/, '')} />
                    {links.length > 0 && (
                      <div className="mt-3 flex flex-wrap gap-1.5">
                        {links.map((href) => (
                          <Link
                            key={href}
                            href={href}
                            onClick={onNavigate}
                            className="rounded-full border border-primary/40 bg-primary/10 px-2.5 py-1 font-mono text-[11px] text-foreground hover:bg-primary/20"
                          >
                            {'→ '}
                            {ROUTES[href] ?? href.replace('/projects/', 'Project: ')}
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                </li>
              )
            })}
            {status === 'submitted' && lastIsUser && (
              <li className="flex gap-3">
                <NikoAvatar state="thinking" className="size-7 shrink-0 text-[10px]" />
                <div className="flex items-center gap-1 rounded-2xl rounded-bl-sm border border-border bg-card px-4 py-3" aria-label="NIKO is thinking">
                  <span className="size-1.5 animate-bounce rounded-full bg-muted-foreground [animation-delay:-0.3s]" />
                  <span className="size-1.5 animate-bounce rounded-full bg-muted-foreground [animation-delay:-0.15s]" />
                  <span className="size-1.5 animate-bounce rounded-full bg-muted-foreground" />
                </div>
              </li>
            )}
          </ol>
        )}
      </div>

      <form
        className="border-t border-border p-3"
        onSubmit={(e) => {
          e.preventDefault()
          ask(input)
        }}
      >
        <div className="flex items-end gap-2 rounded-2xl border border-border bg-card p-2 focus-within:border-primary">
          <NikoAvatar state={state} className="mb-0.5 size-8 shrink-0 text-[10px]" />
          <label htmlFor={compact ? 'niko-input-compact' : 'niko-input'} className="sr-only">
            Message NIKO
          </label>
          <Textarea
            id={compact ? 'niko-input-compact' : 'niko-input'}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey && !(e.nativeEvent.isComposing || e.keyCode === 229)) {
                e.preventDefault()
                ask(input)
              }
            }}
            rows={1}
            maxLength={1000}
            placeholder={guided ? 'Ask about ANIKO (guided mode)…' : 'Ask NIKO anything…'}
            className="max-h-32 min-h-9 flex-1 resize-none border-0 bg-transparent px-1 py-2 shadow-none focus-visible:ring-0 dark:bg-transparent"
          />
          {busy ? (
            <Button type="button" size="icon" variant="secondary" onClick={() => stop()} aria-label="Stop response">
              <Square className="size-3.5" />
            </Button>
          ) : (
            <Button type="submit" size="icon" disabled={!input.trim()} aria-label="Send message">
              <ArrowUp className="size-4" />
            </Button>
          )}
        </div>
        <div className="mt-2 flex items-center justify-between px-1 text-[11px] text-muted-foreground">
          <span>NIKO only shares verified info about the creator.</span>
          {messages.length > 0 && (
            <button type="button" onClick={() => setMessages([])} className="flex items-center gap-1 hover:text-foreground">
              <RotateCcw className="size-3" /> New chat
            </button>
          )}
        </div>
      </form>
    </div>
  )
}
