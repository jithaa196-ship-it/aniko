'use client'

import { useEffect, useMemo, useState } from 'react'
import { ArrowLeft, Check, RotateCcw, Trophy, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { usePrefs } from '@/components/providers/prefs-provider'
import { useLocalStorage } from '@/hooks/use-local-storage'
import { colorDistance, hslToHex, randomHex, readableOn } from '@/lib/export'
import { contrast } from '@/components/studio/colour-lab'
import { RangeField } from '@/components/studio/lab-ui'
import { cn } from '@/lib/utils'

type Difficulty = 'Easy' | 'Medium' | 'Hard'
interface ChallengeMeta { id: string; title: string; description: string; difficulty: Difficulty; max: number }

const CHALLENGES: ChallengeMeta[] = [
  { id: 'principles', title: 'Design Principles', description: 'Five questions on hierarchy, spacing and accessibility.', difficulty: 'Easy', max: 5 },
  { id: 'contrast', title: 'Contrast Detective', description: 'Which pairing passes WCAG AA for body text?', difficulty: 'Easy', max: 6 },
  { id: 'colour-match', title: 'Colour Match', description: 'Recreate a target colour from memory with HSL sliders.', difficulty: 'Medium', max: 100 },
  { id: 'memory', title: 'Pattern Memory', description: 'Watch the grid light up, then repeat the sequence.', difficulty: 'Medium', max: 10 },
  { id: 'hex', title: 'Hex Vision', description: 'Identify the exact hex code of a swatch.', difficulty: 'Hard', max: 8 },
]

type Scores = Record<string, number>
type Report = (score: number) => void

function Feedback({ ok, text }: { ok: boolean; text: string }) {
  return (
    <p role="status" className={cn('flex items-center gap-2 rounded-xl px-3 py-2 text-sm', ok ? 'bg-primary/15 text-primary' : 'bg-destructive/15 text-destructive')}>
      {ok ? <Check className="size-4" /> : <X className="size-4" />} {text}
    </p>
  )
}

function Result({ score, max, onRetry }: { score: number; max: number; onRetry: () => void }) {
  return (
    <div className="flex flex-col items-center gap-4 py-10 text-center">
      <Trophy className="size-10 text-primary" />
      <p className="font-display text-4xl">{score} / {max}</p>
      <p className="text-muted-foreground">{score / max >= 0.8 ? 'Outstanding work.' : score / max >= 0.5 ? 'Solid — try again to improve.' : 'Keep experimenting.'}</p>
      <Button onClick={onRetry}><RotateCcw className="size-4" /> Play again</Button>
    </div>
  )
}

/* ---------- Multiple-choice engine ---------- */
interface MCQ { prompt: React.ReactNode; options: { label: React.ReactNode; key: string }[]; answer: string; explain: string }

function Quiz({ questions, report }: { questions: MCQ[]; report: Report }) {
  const { play } = usePrefs()
  const [i, setI] = useState(0)
  const [picked, setPicked] = useState<string | null>(null)
  const [score, setScore] = useState(0)
  const [done, setDone] = useState(false)
  const q = questions[i]

  const choose = (k: string) => {
    if (picked) return
    setPicked(k)
    const ok = k === q.answer
    play(ok ? 'success' : 'error')
    if (ok) setScore((s) => s + 1)
  }
  const next = () => {
    if (i + 1 >= questions.length) {
      setDone(true)
      report(score)
    } else {
      setI(i + 1)
      setPicked(null)
    }
  }

  if (done) return <Result score={score} max={questions.length} onRetry={() => { setI(0); setPicked(null); setScore(0); setDone(false) }} />

  return (
    <div className="flex flex-col gap-5">
      <p className="font-mono text-xs text-muted-foreground">Question {i + 1} of {questions.length} · Score {score}</p>
      <div className="text-lg">{q.prompt}</div>
      <div className="grid gap-2 sm:grid-cols-2">
        {q.options.map((o) => (
          <button
            key={o.key}
            type="button"
            onClick={() => choose(o.key)}
            disabled={!!picked}
            className={cn(
              'rounded-2xl border p-4 text-left transition-colors',
              !picked && 'border-border hover:border-primary',
              picked && o.key === q.answer && 'border-primary bg-primary/10',
              picked === o.key && o.key !== q.answer && 'border-destructive bg-destructive/10',
              picked && o.key !== q.answer && picked !== o.key && 'border-border opacity-50',
            )}
          >
            {o.label}
          </button>
        ))}
      </div>
      {picked && (
        <>
          <Feedback ok={picked === q.answer} text={q.explain} />
          <Button className="w-fit" onClick={next}>{i + 1 >= questions.length ? 'See result' : 'Next question'}</Button>
        </>
      )}
    </div>
  )
}

const principleQs: MCQ[] = [
  { prompt: 'What is the minimum WCAG AA contrast ratio for normal body text?', options: ['3:1', '4.5:1', '7:1', '2:1'].map((x) => ({ key: x, label: x })), answer: '4.5:1', explain: 'AA requires 4.5:1 for body text and 3:1 for large text.' },
  { prompt: 'Which principle groups related items closer together?', options: ['Proximity', 'Contrast', 'Repetition', 'Alignment'].map((x) => ({ key: x, label: x })), answer: 'Proximity', explain: 'Proximity signals relationships through spacing.' },
  { prompt: 'A comfortable line length for body text is roughly…', options: ['20–30 characters', '45–75 characters', '100–140 characters', 'As wide as the screen'].map((x) => ({ key: x, label: x })), answer: '45–75 characters', explain: 'Around 45–75 characters per line reads most comfortably.' },
  { prompt: 'The minimum recommended touch target size on mobile is about…', options: ['16px', '24px', '44px', '80px'].map((x) => ({ key: x, label: x })), answer: '44px', explain: 'Platform guidelines recommend roughly 44–48px targets.' },
  { prompt: 'Visual hierarchy is primarily created with…', options: ['Size, weight and colour', 'Only animation', 'Random placement', 'More fonts'].map((x) => ({ key: x, label: x })), answer: 'Size, weight and colour', explain: 'Scale, weight and colour guide the eye in order of importance.' },
]

function makeContrastQs(): MCQ[] {
  return Array.from({ length: 6 }, (_, n) => {
    const pairs: [string, string][] = []
    while (pairs.length < 4) {
      const a = randomHex()
      const b = Math.random() > 0.5 ? hslToHex(Math.random() * 360, 30, Math.random() > 0.5 ? 95 : 8) : randomHex()
      pairs.push([a, b])
    }
    const passing = pairs.findIndex(([a, b]) => contrast(a, b) >= 4.5)
    if (passing === -1) pairs[Math.floor(Math.random() * 4)] = [hslToHex(Math.random() * 360, 60, 92), hslToHex(Math.random() * 360, 60, 14)]
    const answerIdx = pairs.findIndex(([a, b]) => contrast(a, b) >= 4.5)
    const others = pairs.map(([a, b], i) => (i !== answerIdx && contrast(a, b) >= 4.5 ? ([a, hslToHex(0, 0, 55)] as [string, string]) : [a, b]))
    const fixed = others.map(([a, b], i) => (i !== answerIdx && contrast(a, b) >= 4.5 ? [a, a] : [a, b]))
    return {
      prompt: `Round ${n + 1}: which pair passes AA (4.5:1) for body text?`,
      options: fixed.map(([fg, bg], i) => ({
        key: String(i),
        label: (
          <span className="flex flex-col gap-2">
            <span className="rounded-lg p-3 text-sm" style={{ background: bg, color: fg }}>The quick brown fox</span>
            <span className="font-mono text-xs text-muted-foreground">{contrast(fg, bg).toFixed(2)}:1 hidden until answered</span>
          </span>
        ),
      })),
      answer: String(answerIdx),
      explain: `The passing pair scores ${contrast(fixed[answerIdx][0], fixed[answerIdx][1]).toFixed(2)}:1.`,
    }
  })
}

function makeHexQs(): MCQ[] {
  return Array.from({ length: 8 }, () => {
    const target = randomHex()
    const opts = [target, ...Array.from({ length: 3 }, () => randomHex())].sort(() => Math.random() - 0.5)
    return {
      prompt: <span className="flex items-center gap-4">Which hex is this? <span aria-label="Colour swatch" role="img" className="inline-block size-14 rounded-2xl border border-border" style={{ background: target }} /></span>,
      options: opts.map((o) => ({ key: o, label: <span className="font-mono uppercase">{o}</span> })),
      answer: target,
      explain: `It was ${target.toUpperCase()}.`,
    }
  })
}

/* ---------- Colour match ---------- */
function ColourMatch({ report }: { report: Report }) {
  const { play } = usePrefs()
  const [target, setTarget] = useState(() => hslToHex(Math.random() * 360, 50 + Math.random() * 40, 35 + Math.random() * 30))
  const [phase, setPhase] = useState<'memorise' | 'guess' | 'done'>('memorise')
  const [h, setH] = useState(180)
  const [s, setS] = useState(50)
  const [l, setL] = useState(50)
  const guess = hslToHex(h, s, l)
  const score = Math.max(0, Math.round(100 - (colorDistance(guess, target) / 441) * 220))

  useEffect(() => {
    if (phase !== 'memorise') return
    const t = setTimeout(() => setPhase('guess'), 3000)
    return () => clearTimeout(t)
  }, [phase])

  if (phase === 'memorise') {
    return (
      <div className="flex flex-col items-center gap-4 py-6">
        <p className="font-mono text-xs text-muted-foreground">Memorise this colour — 3 seconds</p>
        <div role="img" aria-label="Target colour" className="size-48 rounded-3xl border border-border" style={{ background: target }} />
      </div>
    )
  }

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <div className="flex flex-col gap-5">
        <RangeField label="Hue" value={h} min={0} max={360} unit="°" onChange={setH} />
        <RangeField label="Saturation" value={s} min={0} max={100} unit="%" onChange={setS} />
        <RangeField label="Lightness" value={l} min={0} max={100} unit="%" onChange={setL} />
        {phase === 'guess' ? (
          <Button onClick={() => { setPhase('done'); play(score >= 70 ? 'success' : 'error'); report(score) }}>Lock in guess</Button>
        ) : (
          <>
            <Feedback ok={score >= 70} text={`Accuracy ${score} / 100`} />
            <Button variant="outline" onClick={() => { setTarget(hslToHex(Math.random() * 360, 50 + Math.random() * 40, 35 + Math.random() * 30)); setPhase('memorise') }}>
              <RotateCcw className="size-4" /> New colour
            </Button>
          </>
        )}
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div className="flex aspect-square flex-col justify-end rounded-3xl border border-border p-3 font-mono text-xs" style={{ background: guess, color: readableOn(guess) }}>Your guess<br />{guess.toUpperCase()}</div>
        <div className="flex aspect-square flex-col justify-end rounded-3xl border border-dashed border-border p-3 font-mono text-xs" style={phase === 'done' ? { background: target, color: readableOn(target) } : undefined}>
          Target<br />{phase === 'done' ? target.toUpperCase() : 'hidden'}
        </div>
      </div>
    </div>
  )
}

/* ---------- Pattern memory ---------- */
function PatternMemory({ report }: { report: Report }) {
  const { play, reducedMotion } = usePrefs()
  const [seq, setSeq] = useState<number[]>([])
  const [input, setInput] = useState<number[]>([])
  const [flash, setFlash] = useState<number | null>(null)
  const [state, setState] = useState<'idle' | 'showing' | 'input' | 'over'>('idle')
  const level = Math.max(0, seq.length - 1)

  const show = async (s: number[]) => {
    setState('showing')
    const step = reducedMotion ? 450 : 600
    for (const cell of s) {
      await new Promise((r) => setTimeout(r, step / 3))
      setFlash(cell)
      play('tap')
      await new Promise((r) => setTimeout(r, step))
      setFlash(null)
    }
    setInput([])
    setState('input')
  }
  const start = () => {
    const s = [Math.floor(Math.random() * 9)]
    setSeq(s)
    show(s)
  }
  const press = (c: number) => {
    if (state !== 'input') return
    const next = [...input, c]
    if (seq[next.length - 1] !== c) {
      play('error')
      setState('over')
      report(Math.min(10, level))
      return
    }
    setInput(next)
    if (next.length === seq.length) {
      play('success')
      if (seq.length >= 11) { setState('over'); report(10); return }
      const s = [...seq, Math.floor(Math.random() * 9)]
      setSeq(s)
      setTimeout(() => show(s), 500)
    }
  }

  return (
    <div className="flex flex-col items-center gap-6">
      <p className="font-mono text-xs text-muted-foreground" aria-live="polite">
        {state === 'idle' && 'Press start, then repeat the sequence'}
        {state === 'showing' && 'Watch…'}
        {state === 'input' && `Your turn — ${input.length}/${seq.length}`}
        {state === 'over' && `Game over · reached level ${level}`}
      </p>
      <div className="grid grid-cols-3 gap-3">
        {Array.from({ length: 9 }, (_, c) => (
          <button
            key={c}
            type="button"
            aria-label={`Cell ${c + 1}`}
            disabled={state !== 'input'}
            onClick={() => press(c)}
            className={cn('size-20 rounded-2xl border border-border transition-all md:size-24', flash === c ? 'scale-95 bg-primary shadow-[0_0_40px_var(--primary)]' : 'bg-card hover:bg-muted')}
          />
        ))}
      </div>
      {(state === 'idle' || state === 'over') && <Button onClick={start}>{state === 'over' ? 'Try again' : 'Start'}</Button>}
    </div>
  )
}

/* ---------- Shell ---------- */
export function Challenges() {
  const [scores, setScores] = useLocalStorage<Scores>('aniko:challenge-scores', {})
  const [active, setActive] = useState<string | null>(null)
  const [round, setRound] = useState(0)
  const meta = CHALLENGES.find((c) => c.id === active)
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const contrastQs = useMemo(() => makeContrastQs(), [round, active])
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const hexQs = useMemo(() => makeHexQs(), [round, active])

  const report = (id: string) => (score: number) => {
    setScores((p) => ({ ...p, [id]: Math.max(p[id] ?? 0, score) }))
    setRound((r) => r + 1)
  }
  const total = CHALLENGES.reduce((n, c) => n + Math.round(((scores[c.id] ?? 0) / c.max) * 100), 0)

  if (meta) {
    return (
      <div className="glass rounded-3xl p-6 md:p-10">
        <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
          <Button variant="ghost" size="sm" onClick={() => setActive(null)}><ArrowLeft className="size-4" /> All challenges</Button>
          <p className="font-mono text-xs text-muted-foreground">{meta.difficulty} · Best {scores[meta.id] ?? 0}/{meta.max}</p>
        </div>
        <h2 className="mb-6 font-display text-2xl">{meta.title}</h2>
        {meta.id === 'principles' && <Quiz key={round} questions={principleQs} report={report(meta.id)} />}
        {meta.id === 'contrast' && <Quiz key={round} questions={contrastQs} report={report(meta.id)} />}
        {meta.id === 'hex' && <Quiz key={round} questions={hexQs} report={report(meta.id)} />}
        {meta.id === 'colour-match' && <ColourMatch report={report(meta.id)} />}
        {meta.id === 'memory' && <PatternMemory report={report(meta.id)} />}
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-8">
      <div className="glass flex flex-wrap items-center justify-between gap-4 rounded-3xl p-6">
        <div>
          <p className="eyebrow">Creator score</p>
          <p className="mt-2 font-display text-4xl">{total}<span className="text-lg text-muted-foreground"> / 500</span></p>
        </div>
        <Button variant="outline" size="sm" onClick={() => setScores({})} disabled={!Object.keys(scores).length}>Reset scores</Button>
      </div>
      <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {CHALLENGES.map((c, i) => {
          const best = scores[c.id]
          return (
            <li key={c.id}>
              <button type="button" onClick={() => setActive(c.id)} className="group flex h-full w-full flex-col gap-6 rounded-3xl border border-border bg-card p-6 text-left transition-colors hover:border-primary">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs text-muted-foreground">{String(i + 1).padStart(2, '0')}</span>
                  <span className={cn('rounded-full px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider', c.difficulty === 'Easy' ? 'bg-glow-3/20' : c.difficulty === 'Medium' ? 'bg-glow-1/20' : 'bg-glow-2/20')}>{c.difficulty}</span>
                </div>
                <div className="flex-1">
                  <h2 className="font-display text-xl group-hover:text-primary">{c.title}</h2>
                  <p className="mt-2 text-sm text-muted-foreground">{c.description}</p>
                </div>
                <div className="flex flex-col gap-2">
                  <div className="h-1.5 overflow-hidden rounded-full bg-muted">
                    <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${((best ?? 0) / c.max) * 100}%` }} />
                  </div>
                  <p className="font-mono text-xs text-muted-foreground">{best === undefined ? 'Not played' : `Best ${best}/${c.max}`}</p>
                </div>
              </button>
            </li>
          )
        })}
      </ul>
    </div>
  )
}
