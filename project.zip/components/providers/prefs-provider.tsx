'use client'

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useSyncExternalStore } from 'react'
import { useLocalStorage } from '@/hooks/use-local-storage'

type SoundKind = 'tap' | 'enter' | 'success' | 'error'

interface Prefs {
  soundOn: boolean
  setSoundOn: (v: boolean) => void
  reducedMotion: boolean
  setReducedMotionPref: (v: 'system' | 'on' | 'off') => void
  motionPref: 'system' | 'on' | 'off'
  customCursor: boolean
  setCustomCursor: (v: boolean) => void
  play: (kind?: SoundKind) => void
}

const PrefsContext = createContext<Prefs | null>(null)

function useSystemReducedMotion() {
  return useSyncExternalStore(
    (cb) => {
      const mq = window.matchMedia('(prefers-reduced-motion: reduce)')
      mq.addEventListener('change', cb)
      return () => mq.removeEventListener('change', cb)
    },
    () => window.matchMedia('(prefers-reduced-motion: reduce)').matches,
    () => false,
  )
}

const tones: Record<SoundKind, [number, number, number]> = {
  tap: [660, 0.05, 0.04],
  enter: [440, 0.35, 0.06],
  success: [880, 0.18, 0.05],
  error: [180, 0.2, 0.05],
}

export function PrefsProvider({ children }: { children: React.ReactNode }) {
  const [soundOn, setSoundOn] = useLocalStorage('aniko:sound', false)
  const [motionPref, setReducedMotionPref] = useLocalStorage<'system' | 'on' | 'off'>('aniko:motion', 'system')
  const [customCursor, setCustomCursor] = useLocalStorage('aniko:cursor', true)
  const system = useSystemReducedMotion()
  const reducedMotion = motionPref === 'system' ? system : motionPref === 'on'
  const ctxRef = useRef<AudioContext | null>(null)

  useEffect(() => {
    document.documentElement.classList.toggle('reduce-motion', reducedMotion)
  }, [reducedMotion])

  const play = useCallback(
    (kind: SoundKind = 'tap') => {
      if (!soundOn) return
      try {
        ctxRef.current ??= new AudioContext()
        const ctx = ctxRef.current
        const [freq, dur, vol] = tones[kind]
        const osc = ctx.createOscillator()
        const gain = ctx.createGain()
        osc.type = kind === 'enter' ? 'sine' : 'triangle'
        osc.frequency.setValueAtTime(freq, ctx.currentTime)
        if (kind === 'enter') osc.frequency.exponentialRampToValueAtTime(freq * 2, ctx.currentTime + dur)
        gain.gain.setValueAtTime(vol, ctx.currentTime)
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur)
        osc.connect(gain).connect(ctx.destination)
        osc.start()
        osc.stop(ctx.currentTime + dur)
      } catch {
        /* Web Audio unavailable */
      }
    },
    [soundOn],
  )

  const value = useMemo(
    () => ({ soundOn, setSoundOn, reducedMotion, setReducedMotionPref, motionPref, customCursor, setCustomCursor, play }),
    [soundOn, setSoundOn, reducedMotion, setReducedMotionPref, motionPref, customCursor, setCustomCursor, play],
  )

  return <PrefsContext.Provider value={value}>{children}</PrefsContext.Provider>
}

export function usePrefs() {
  const ctx = useContext(PrefsContext)
  if (!ctx) throw new Error('usePrefs must be used within PrefsProvider')
  return ctx
}
