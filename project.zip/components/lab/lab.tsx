'use client'

import dynamic from 'next/dynamic'
import { useRef, useState } from 'react'
import { Camera, RotateCcw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { usePrefs } from '@/components/providers/prefs-provider'
import { downloadCanvas } from '@/lib/export'
import { ColorField, LabPanel, RangeField, Segmented } from '@/components/studio/lab-ui'
import { LIGHTS, MATERIALS, SHAPES, type LabState } from './lab-scene'

const LabScene = dynamic(() => import('./lab-scene'), {
  ssr: false,
  loading: () => (
    <div role="status" className="grid size-full place-items-center font-mono text-xs uppercase tracking-[0.24em] text-white/60">
      Booting laboratory
    </div>
  ),
})

const initial: LabState = { shape: 'torusKnot', material: 'metal', lighting: 'neon', color: '#a78bfa', speed: 0.5, autoRotate: false }

export function Lab() {
  const { reducedMotion } = usePrefs()
  const [s, setS] = useState<LabState>({ ...initial, speed: reducedMotion ? 0 : initial.speed })
  const wrap = useRef<HTMLDivElement>(null)
  const set = (patch: Partial<LabState>) => setS((p) => ({ ...p, ...patch }))

  const capture = () => {
    const canvas = wrap.current?.querySelector('canvas')
    if (canvas) downloadCanvas(canvas, `aniko-lab-${s.shape}.png`)
  }

  return (
    <LabPanel
      controls={
        <>
          <Segmented label="Object" value={s.shape} options={SHAPES} onChange={(shape) => set({ shape })} />
          <Segmented label="Material" value={s.material} options={MATERIALS} onChange={(material) => set({ material })} />
          <Segmented label="Lighting" value={s.lighting} options={LIGHTS} onChange={(lighting) => set({ lighting })} />
          <ColorField label="Colour" value={s.color} onChange={(color) => set({ color })} />
          <RangeField label="Animation speed" value={s.speed} min={0} max={3} step={0.1} unit="x" onChange={(speed) => set({ speed })} />
          <div className="flex items-center justify-between">
            <Label htmlFor="autorotate" className="text-sm">Orbit camera</Label>
            <Switch id="autorotate" checked={s.autoRotate} onCheckedChange={(autoRotate) => set({ autoRotate })} />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <Button variant="outline" onClick={() => setS(initial)}><RotateCcw className="size-4" /> Reset</Button>
            <Button onClick={capture}><Camera className="size-4" /> Screenshot</Button>
          </div>
          <p className="text-xs text-muted-foreground">Drag to rotate, scroll or pinch to zoom.</p>
        </>
      }
      preview={
        <div ref={wrap} className="aspect-square overflow-hidden rounded-3xl border border-border bg-[#0b0918] md:aspect-[4/3]" aria-label="Interactive 3D object viewer" role="region">
          <LabScene s={s} />
        </div>
      }
    />
  )
}
