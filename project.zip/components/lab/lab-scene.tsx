'use client'

import { Canvas, useFrame } from '@react-three/fiber'
import { ContactShadows, Environment, OrbitControls } from '@react-three/drei'
import { useRef } from 'react'
import type { Mesh } from 'three'

export const SHAPES = ['torusKnot', 'sphere', 'box', 'icosahedron', 'torus', 'cone'] as const
export const MATERIALS = ['standard', 'metal', 'glass', 'wireframe', 'toon'] as const
export const LIGHTS = ['studio', 'neon', 'sunset'] as const

export interface LabState {
  shape: (typeof SHAPES)[number]
  material: (typeof MATERIALS)[number]
  lighting: (typeof LIGHTS)[number]
  color: string
  speed: number
  autoRotate: boolean
}

function Geometry({ shape }: { shape: LabState['shape'] }) {
  switch (shape) {
    case 'torusKnot': return <torusKnotGeometry args={[0.9, 0.3, 200, 32]} />
    case 'sphere': return <sphereGeometry args={[1.2, 64, 64]} />
    case 'box': return <boxGeometry args={[1.6, 1.6, 1.6]} />
    case 'icosahedron': return <icosahedronGeometry args={[1.3, 0]} />
    case 'torus': return <torusGeometry args={[1, 0.38, 48, 120]} />
    case 'cone': return <coneGeometry args={[1.1, 2, 64]} />
  }
}

function Material({ s }: { s: LabState }) {
  switch (s.material) {
    case 'metal': return <meshStandardMaterial color={s.color} metalness={1} roughness={0.15} />
    case 'glass': return <meshPhysicalMaterial color={s.color} transmission={1} thickness={1.2} roughness={0.05} ior={1.4} />
    case 'wireframe': return <meshBasicMaterial color={s.color} wireframe />
    case 'toon': return <meshToonMaterial color={s.color} />
    default: return <meshStandardMaterial color={s.color} roughness={0.4} />
  }
}

function Model({ s }: { s: LabState }) {
  const ref = useRef<Mesh>(null)
  useFrame((_, dt) => {
    if (!ref.current) return
    ref.current.rotation.y += dt * s.speed
    ref.current.rotation.x += dt * s.speed * 0.4
  })
  return (
    <mesh ref={ref} castShadow>
      <Geometry shape={s.shape} />
      <Material s={s} />
    </mesh>
  )
}

const lightPresets = {
  studio: { bg: '#18152a', env: 'studio', a: '#ffffff', b: '#ffffff' },
  neon: { bg: '#0b0918', env: 'night', a: '#f472b6', b: '#67e8f9' },
  sunset: { bg: '#2a1620', env: 'sunset', a: '#fdba74', b: '#a78bfa' },
} as const

export default function LabScene({ s }: { s: LabState }) {
  const L = lightPresets[s.lighting]
  return (
    <Canvas shadows camera={{ position: [0, 0.5, 5], fov: 45 }} gl={{ preserveDrawingBuffer: true }} dpr={[1, 2]}>
      <color attach="background" args={[L.bg]} />
      <ambientLight intensity={0.3} />
      <pointLight position={[4, 3, 3]} intensity={40} color={L.a} />
      <pointLight position={[-4, -2, 2]} intensity={25} color={L.b} />
      <Environment preset={L.env} />
      <Model s={s} />
      <ContactShadows position={[0, -1.8, 0]} opacity={0.5} scale={8} blur={2.5} />
      <OrbitControls autoRotate={s.autoRotate} autoRotateSpeed={1.5} enablePan={false} minDistance={2.5} maxDistance={9} />
    </Canvas>
  )
}
