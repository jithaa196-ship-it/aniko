export type ZoneShape = 'icosahedron' | 'sphere' | 'torusKnot' | 'box' | 'octahedron' | 'cylinder' | 'tetrahedron' | 'torus'

export interface Zone {
  id: string
  index: string
  title: string
  description: string
  href: string
  color: string
  shape: ZoneShape
}

export const zones: Zone[] = [
  { id: 'universe', index: '01', title: '3D Universe', description: 'The living map of ANIKO — every zone orbits here.', href: '/#universe', color: '#a78bfa', shape: 'icosahedron' },
  { id: 'niko', index: '02', title: 'NIKO AI', description: 'Talk to NIKO, the holographic guide of the lab.', href: '/niko', color: '#67e8f9', shape: 'sphere' },
  { id: 'studio', index: '03', title: 'Creative Studio', description: 'Colour, gradient, type, UI and pattern experiments.', href: '/studio', color: '#f472b6', shape: 'torusKnot' },
  { id: 'lab', index: '04', title: '3D Laboratory', description: 'Shape, light and animate procedural geometry.', href: '/lab', color: '#c4b5fd', shape: 'box' },
  { id: 'projects', index: '05', title: 'Project Exhibition', description: 'Case studies across design, web and electronics.', href: '/projects', color: '#f9a8d4', shape: 'octahedron' },
  { id: 'archive', index: '06', title: 'Knowledge Archive', description: 'Notes, inspiration and discoveries — editable.', href: '/archive', color: '#a5f3fc', shape: 'cylinder' },
  { id: 'challenges', index: '07', title: 'Challenge Zone', description: 'Quick creative challenges with live scoring.', href: '/challenges', color: '#fbcfe8', shape: 'tetrahedron' },
  { id: 'creator', index: '08', title: 'Creator Hub', description: 'Meet Abhijitha JM, the mind behind ANIKO.', href: '/creator', color: '#ddd6fe', shape: 'torus' },
]

export const navItems = [
  { label: 'Home', href: '/' },
  { label: 'Universe', href: '/#universe' },
  { label: 'Experiments', href: '/studio' },
  { label: 'NIKO AI', href: '/niko' },
  { label: 'Projects', href: '/projects' },
  { label: 'Archive', href: '/archive' },
  { label: 'Creator', href: '/creator' },
  { label: 'Contact', href: '/contact' },
] as const
