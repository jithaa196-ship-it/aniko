/**
 * Centralized project database.
 * Every entry below is PLACEHOLDER material (isPlaceholder: true) so the
 * exhibition is usable before real work is added. Replace these entries with
 * real projects and set isPlaceholder to false. Leave links empty rather than
 * inventing them — empty links are hidden in the UI.
 */
export const projectCategories = [
  'UI/UX Design',
  'Graphic Design',
  'Web Development',
  'Electronics',
  'Creative Experiments',
] as const

export type ProjectCategory = (typeof projectCategories)[number]
export type ProjectStatus = 'Concept' | 'In progress' | 'Completed'

export interface Project {
  slug: string
  title: string
  summary: string
  category: ProjectCategory
  tools: string[]
  status: ProjectStatus
  date: string
  cover: string
  gallery: string[]
  githubUrl: string
  liveUrl: string
  isPlaceholder: boolean
  caseStudy: {
    overview: string
    problem: string
    research: string
    ideation: string
    process: string
    technology: string
    outcome: string
    learnings: string
  }
}

const placeholderCase = (topic: string): Project['caseStudy'] => ({
  overview: `Placeholder overview for ${topic}. Describe what the project is and who it is for.`,
  problem: 'Placeholder: state the problem or opportunity this project addresses.',
  research: 'Placeholder: summarise research methods, references and insights.',
  ideation: 'Placeholder: outline sketches, concepts and directions explored.',
  process: 'Placeholder: walk through the design and build process step by step.',
  technology: 'Placeholder: explain the tools and technology used and why.',
  outcome: 'Placeholder: present the final outcome with visuals.',
  learnings: 'Placeholder: reflect on what you learned and what you would change.',
})

export const projects: Project[] = [
  {
    slug: 'sample-mobile-app-ui',
    title: 'Sample — Mobile App Interface',
    summary: 'Placeholder UI/UX case study slot for a mobile app design created in Figma.',
    category: 'UI/UX Design',
    tools: ['Figma'],
    status: 'Concept',
    date: '2026-03-01',
    cover: '/projects/uiux.png',
    gallery: ['/projects/uiux.png', '/projects/experiment.png'],
    githubUrl: '',
    liveUrl: '',
    isPlaceholder: true,
    caseStudy: placeholderCase('a mobile app interface'),
  },
  {
    slug: 'sample-poster-series',
    title: 'Sample — Poster Series',
    summary: 'Placeholder graphic design slot for posters or social visuals made in Canva.',
    category: 'Graphic Design',
    tools: ['Canva'],
    status: 'Concept',
    date: '2026-02-10',
    cover: '/projects/graphic.png',
    gallery: ['/projects/graphic.png', '/projects/uiux.png'],
    githubUrl: '',
    liveUrl: '',
    isPlaceholder: true,
    caseStudy: placeholderCase('a poster series'),
  },
  {
    slug: 'sample-responsive-website',
    title: 'Sample — Responsive Website',
    summary: 'Placeholder web development slot for a site built with HTML, CSS and JavaScript.',
    category: 'Web Development',
    tools: ['HTML', 'CSS', 'JavaScript'],
    status: 'In progress',
    date: '2026-04-05',
    cover: '/projects/web.png',
    gallery: ['/projects/web.png', '/projects/graphic.png'],
    githubUrl: '',
    liveUrl: '',
    isPlaceholder: true,
    caseStudy: placeholderCase('a responsive website'),
  },
  {
    slug: 'sample-esp32-iot-node',
    title: 'Sample — ESP32 IoT Node',
    summary: 'Placeholder electronics slot for an ESP32 sensor or IoT project.',
    category: 'Electronics',
    tools: ['ESP32', 'C', 'Embedded Systems', 'IoT'],
    status: 'In progress',
    date: '2026-05-12',
    cover: '/projects/electronics.png',
    gallery: ['/projects/electronics.png', '/projects/web.png'],
    githubUrl: '',
    liveUrl: '',
    isPlaceholder: true,
    caseStudy: placeholderCase('an ESP32 IoT node'),
  },
  {
    slug: 'aniko-digital-universe',
    title: 'ANIKO — Experimental Digital Universe',
    summary: 'This website: a 3D creative technology lab with an AI guide, design playground and 3D laboratory.',
    category: 'Creative Experiments',
    tools: ['Next.js', 'React', 'TypeScript', 'Three.js', 'Tailwind CSS'],
    status: 'In progress',
    date: '2026-11-20',
    cover: '/projects/experiment.png',
    gallery: ['/projects/experiment.png', '/projects/electronics.png'],
    githubUrl: '',
    liveUrl: '',
    isPlaceholder: false,
    caseStudy: {
      overview: 'ANIKO is an immersive digital universe combining a 3D environment, an AI lab assistant named NIKO and a set of creative experimentation tools.',
      problem: 'Traditional portfolios present work statically. ANIKO explores how a portfolio can become an interactive place to experiment and learn.',
      research: 'Add your research notes here — references, inspiration and observations from other creative technology sites.',
      ideation: 'The site is organised as eight experimental zones, each with its own visual identity and 3D object.',
      process: 'Built with modular React components, a centralized configuration file and separate data files for projects, skills and the archive.',
      technology: 'Next.js, React, TypeScript, Tailwind CSS, Three.js with React Three Fiber, Motion, the AI SDK and the public GitHub API.',
      outcome: 'A working lab: 3D universe, NIKO chat, Creative Studio, 3D Laboratory, project exhibition, archive, challenges and creator hub.',
      learnings: 'Add your learnings here once the project has been shared and used.',
    },
  },
]

export function getProject(slug: string) {
  return projects.find((p) => p.slug === slug)
}
