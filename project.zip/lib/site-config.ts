/**
 * Central, editable configuration for ANIKO.
 * Replace empty strings with real values. Empty values are hidden or shown
 * as "not configured" in the UI — nothing is ever invented.
 */
export const siteConfig = {
  name: 'ANIKO',
  tagline: 'Explore. Experiment. Evolve.',
  description:
    'An experimental digital universe where creativity, artificial intelligence and technology come together.',
  url: 'https://aniko.vercel.app',
  creator: {
    name: 'Abhijitha JM',
    role: 'Electronics and Communication Engineering student',
    intro:
      "I'm Abhijitha JM, an Electronics and Communication Engineering student interested in UI/UX design, graphic design, creative technology and digital experimentation.",
    about: [
      'ANIKO is my personal laboratory — a place to explore how design, code and electronics can come together into experiences that feel alive.',
      'I enjoy moving between pixels and circuits: sketching interfaces in Figma, building layouts with HTML and CSS, and experimenting with microcontrollers like the ESP32.',
    ],
    education: [
      {
        title: 'B.E. / B.Tech — Electronics and Communication Engineering',
        institution: '',
        period: '',
        status: 'In progress',
      },
    ],
    interests: [
      'UI/UX design',
      'Graphic design',
      'Creative technology',
      'Digital experimentation',
      'Embedded systems & IoT',
      'Generative visuals',
    ],
    journey: [
      { label: 'Design foundations', detail: 'Exploring layout, colour and typography through Canva and Figma.' },
      { label: 'Web fundamentals', detail: 'Learning HTML, CSS and JavaScript to bring designs to the browser.' },
      { label: 'Programming in C', detail: 'Building problem-solving skills through ECE coursework.' },
      { label: 'Hardware experiments', detail: 'Working with ESP32, sensors and embedded systems for IoT ideas.' },
      { label: 'ANIKO', detail: 'Combining it all into one experimental digital universe.' },
    ],
  },
  links: {
    /** Public GitHub username used by the live GitHub integration. */
    githubUsername: '',
    /** Full LinkedIn profile URL, e.g. https://www.linkedin.com/in/your-handle */
    linkedin: '',
    /** Public contact email. */
    email: '',
    /** Path or URL to a resume PDF (e.g. /resume.pdf placed in /public). */
    resume: '',
  },
  niko: {
    model: 'openai/gpt-5.4-mini',
  },
} as const

export const githubUrl = siteConfig.links.githubUsername
  ? `https://github.com/${siteConfig.links.githubUsername}`
  : ''
