export type SkillGroup = 'Design' | 'Programming' | 'Technology'
export type LearningStatus = 'Exploring' | 'Learning' | 'Practising'

export interface Skill {
  id: string
  name: string
  group: SkillGroup
  description: string
  tools: string[]
  status: LearningStatus
  /** Slugs from lib/projects.ts */
  relatedProjects: string[]
}

export const skillGroups: { name: SkillGroup; color: string }[] = [
  { name: 'Design', color: '#f472b6' },
  { name: 'Programming', color: '#a78bfa' },
  { name: 'Technology', color: '#67e8f9' },
]

/** Learning status is self-described and editable. No percentages or certifications. */
export const skills: Skill[] = [
  { id: 'figma', name: 'Figma', group: 'Design', description: 'Interface design, wireframes and prototypes.', tools: ['Figma'], status: 'Practising', relatedProjects: ['sample-mobile-app-ui'] },
  { id: 'canva', name: 'Canva', group: 'Design', description: 'Posters, social visuals and quick layouts.', tools: ['Canva'], status: 'Practising', relatedProjects: ['sample-poster-series'] },
  { id: 'uiux', name: 'UI/UX Design', group: 'Design', description: 'User-centred flows, hierarchy and interaction design.', tools: ['Figma'], status: 'Learning', relatedProjects: ['sample-mobile-app-ui', 'aniko-digital-universe'] },
  { id: 'graphic', name: 'Graphic Design', group: 'Design', description: 'Colour, typography and composition for visual communication.', tools: ['Canva', 'Figma'], status: 'Learning', relatedProjects: ['sample-poster-series'] },
  { id: 'c', name: 'C', group: 'Programming', description: 'Procedural programming foundations and embedded firmware.', tools: ['C'], status: 'Learning', relatedProjects: ['sample-esp32-iot-node'] },
  { id: 'html', name: 'HTML', group: 'Programming', description: 'Semantic, accessible page structure.', tools: ['HTML'], status: 'Practising', relatedProjects: ['sample-responsive-website'] },
  { id: 'css', name: 'CSS', group: 'Programming', description: 'Layouts, responsive design and visual styling.', tools: ['CSS'], status: 'Practising', relatedProjects: ['sample-responsive-website', 'aniko-digital-universe'] },
  { id: 'js', name: 'JavaScript', group: 'Programming', description: 'Interactivity and logic in the browser.', tools: ['JavaScript'], status: 'Learning', relatedProjects: ['sample-responsive-website'] },
  { id: 'electronics', name: 'Electronics', group: 'Technology', description: 'Circuits and components from ECE studies.', tools: ['Breadboard', 'Multimeter'], status: 'Learning', relatedProjects: ['sample-esp32-iot-node'] },
  { id: 'esp32', name: 'ESP32', group: 'Technology', description: 'Wi-Fi and Bluetooth enabled microcontroller experiments.', tools: ['ESP32', 'Arduino IDE'], status: 'Exploring', relatedProjects: ['sample-esp32-iot-node'] },
  { id: 'embedded', name: 'Embedded Systems', group: 'Technology', description: 'Programming hardware that interacts with the physical world.', tools: ['C', 'ESP32'], status: 'Exploring', relatedProjects: ['sample-esp32-iot-node'] },
  { id: 'iot', name: 'IoT', group: 'Technology', description: 'Connected devices, sensors and data.', tools: ['ESP32'], status: 'Exploring', relatedProjects: ['sample-esp32-iot-node'] },
]
