export const archiveCategories = [
  'Design inspiration',
  'Creative ideas',
  'Learning notes',
  'Technology discoveries',
  'Experiment history',
  'Reference collections',
] as const

export type ArchiveCategory = (typeof archiveCategories)[number]

export interface ArchiveEntry {
  id: string
  title: string
  category: ArchiveCategory
  body: string
  tags: string[]
  images: string[]
  createdAt: string
  isStarter?: boolean
}

/** Starter entries — editable in the UI and saved to this browser. */
export const starterEntries: ArchiveEntry[] = [
  {
    id: 'starter-colour-contrast',
    title: 'Colour contrast basics',
    category: 'Learning notes',
    body: 'WCAG recommends a contrast ratio of at least 4.5:1 for body text and 3:1 for large text. Test palettes in the Colour Lab before using them.',
    tags: ['accessibility', 'colour'],
    images: [],
    createdAt: '2026-11-01',
    isStarter: true,
  },
  {
    id: 'starter-glass',
    title: 'Glass and depth',
    category: 'Design inspiration',
    body: 'Translucent panels work best with a strong background and restrained blur. Keep text on solid-enough surfaces for readability.',
    tags: ['ui', 'glassmorphism'],
    images: ['/projects/experiment.png', '/projects/uiux.png'],
    createdAt: '2026-11-03',
    isStarter: true,
  },
  {
    id: 'starter-esp32',
    title: 'ESP32 deep sleep',
    category: 'Technology discoveries',
    body: 'The ESP32 can enter deep sleep to save power and wake on a timer or GPIO event — useful for battery-powered IoT sensors.',
    tags: ['esp32', 'iot', 'power'],
    images: ['/projects/electronics.png'],
    createdAt: '2026-11-08',
    isStarter: true,
  },
  {
    id: 'starter-idea',
    title: 'Idea: sound-reactive patterns',
    category: 'Creative ideas',
    body: 'Connect the Pattern Lab to microphone input so pattern density follows the volume of the room.',
    tags: ['generative', 'audio'],
    images: [],
    createdAt: '2026-11-12',
    isStarter: true,
  },
  {
    id: 'starter-type',
    title: 'Type pairing references',
    category: 'Reference collections',
    body: 'Pair a geometric display face with a neutral sans for body text. Limit to two families and use weight for hierarchy.',
    tags: ['typography'],
    images: ['/projects/graphic.png'],
    createdAt: '2026-11-15',
    isStarter: true,
  },
  {
    id: 'starter-history',
    title: 'ANIKO v1 launched',
    category: 'Experiment history',
    body: 'First version of the universe with eight zones, NIKO, the Creative Studio and the 3D Laboratory.',
    tags: ['aniko', 'milestone'],
    images: [],
    createdAt: '2026-11-20',
    isStarter: true,
  },
]
